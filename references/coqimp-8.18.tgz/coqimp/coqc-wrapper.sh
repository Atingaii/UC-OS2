#!/usr/bin/env bash

set -e

coq_compiler=$1
shift

ulimit -s 524288
export OCAMLRUNPARAM="${OCAMLRUNPARAM:-o=5}"
exec "$coq_compiler" "$@"
