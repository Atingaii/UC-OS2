(**************************  uc/OS-II  *******************************)
(*************************** OS_CORE.C *******************************)
(*************** Proof of Interupt Handler OSToyISR ******************)
(**************************** Code:***********************************)
(*
OSToyISR ↝ 
{
1     ++OSIntToyCount′;ₛ
2     STI;ₛ 
3     EOI(1);ₛ     
4     OSIntExit(­);ₛ
5     IRET
 }.
*)
Require Import ucos_include.
Require Import ToyIntPure.
Require Import oscore_common.
Open Scope code_scope.

Lemma toyisr_proof:
  forall ir si p r ct lg,
    Some p = BuildintPre OSToyISR int_spec ir si I OSLInv ct lg->
    Some r = BuildintRet OSToyISR int_spec ir si I OSLInv ct lg->
    exists s,
      os_interrupt OSToyISR = Some s /\
      {| OS_spec , GetHPrio, OSLInv, I, retfalse, r|}|-ct {{p}}s {{Afalse}}.
Proof.
  intros.
  unfold BuildintPre in H.
  simpl in H.
  unfold ipreasrt' in H.
  inverts H.
  unfold  BuildintRet in H0.
  simpl in H0.
  unfold iretasrt' in H0.
  inverts H0.
  unfold os_interrupt.
  simpl.
  eexists.
  split.
  auto.

  unfold invlth_noisr.
  unfold starinv_noisr.
  simpl.

  eapply backward_rule1.
  instantiate (1:= ( <|| toyint ||>  **
    Aisr (isrupd ir OSToyISR true) **
    Ais (OSToyISR :: si) **
    Acs nil ** Aie false ** 
    [|exists k,
      gettopis (OSToyISR :: si) = k /\
      (forall j : nat, (0 <= j < k)%nat ->  (isrupd ir OSToyISR true) j = false)|] ** OSInv ** atoy_inv ** A_dom_lenv nil) **
    p_local OSLInv ct lg).
  intros.
  sep cancel p_local.
  eapply ih_no_lvar'.
  sep normal.
  sep cancel OSInv.
  sep auto.
  pure intro.
  rename H0 into Hisrinv.

  unfold atoy_inv.
  unfold atoy_inv'.
  hoare forward.
  (* intro;tryfalse. *)
  hoare unfold.
  discriminate.
  hoare abscsq.
  apply noabs_oslinv.
  unfold toyint.
  Require Import int_absop_rules.
  eapply absimp_toy_frame.
  unfold OSInv.
  can_change_aop_solver.
  eapply seq_rule.
  hoare lift 1%nat pre.
  eapply sti1_rule'.

  intros.
  instantiate (1:= atoy_inv'** [|isr_is_prop (isrupd ir 1%nat true) (1%nat::si)|]  ** A_dom_lenv nil ** p_local OSLInv ct lg).
  sep lifts (1::3::5::6::7::8::nil)%nat.
 
  eapply toyint_sti_inv_elim;eauto.
  unfold OSInv.
  unfold OSInv in H.
  unfold atoy_inv;unfold atoy_inv'.
  sep auto.
  apply GoodI_I.
  unfold p_local.
  unfold CurTid,LINV,OSLInv.
  go.
  intros.
  sep auto.
  eapply seq_rule.
  eapply eoi_ieon_rule'.
  simpl.
  rewrite Int.unsigned_repr.
  lia.
  rewrite max_unsigned_val.
  lia.
  instantiate (1:=1%nat).
  rewrite Int.unsigned_repr.
  
  simpl.
  auto.
  rewrite max_unsigned_val.
  lia.
  intros.
  unfold getinv.
  unfold I.
  unfold atoy_inv.
  instantiate (1:=  [|isr_is_prop (isrupd ir 1%nat true) (1%nat :: si)|] **A_dom_lenv nil ** p_local OSLInv ct lg).
  unfold A_isr_is_prop.
  sep auto;eauto.
  destruct_s s.
  simpl in H2,H4.
  subst;simpl;auto.
  subst; simpl; auto.
  subst; simpl; auto.
  change (isr_is_prop i i1).
  simpl in H1, H3; subst; exact H0.
  apply GoodI_I.
  unfold p_local.
  unfold CurTid,LINV,OSLInv.
  go.
  sep auto.
  sep cancel p_local.
  simpl;auto.
  simpl;auto.
  eapply abscsq_rule'.
  apply noabs_oslinv.
  eapply absinfer_seq_end;eauto.
  go.
  go.
  unfold p_local.
  unfold LINV.
  unfold OSLInv.
  hoare unfold.
  hoare forward.
  instantiate (1:=  [|isr_is_prop (isrupd ir 1%nat true) (1%nat :: si)|] **A_dom_lenv nil).
  sep cancel Aisr.
  sep cancel Aie.
  sep cancel Ais.
  sep cancel Acs.
  sep cancel 1%nat 1%nat.
  sep cancel 2%nat 4%nat.
  apply disj_split.
  right.
  unfold p_local.
  unfold OSLInv,LINV.
  sep auto.
  auto.
  
  Import DeprecatedTactic.
  split.
  unfold INUM;auto.
  clear -Hisrinv.
  intros.
  apply Hisrinv in H.
  unfold OSToyISR in *.
  unfold isrupd in *.
  destruct (Nat.eqb 1 j);auto.
  rename H0 into Hisr_prop_current.
  unfold isr_is_prop in *.
  intros x0 Hnotin.
  apply Hisr_prop_current in Hnotin.
  unfold isrupd in *.
  destruct (Nat.eqb 1 x0);tryfalse;auto.
  simpl;auto.
  rename H0 into Hisr_prop_entail1.
  rename H1 into Hgood_linv_entail1.
  intros s1 Hsat1.
  sep normal in Hsat1.
  sep destruct Hsat1.
  sep split in Hsat1.
  destruct Hsat1.
  sep auto.
  sep split in H0.
  simpl in H0;tryfalse.
  rename H0 into Hisr_prop_entail2.
  rename H1 into Hgood_linv_entail2.
  intros s2 Hsat2.
  sep normal in Hsat2.
  sep destruct Hsat2.
  sep split in Hsat2.
  sep auto.
  rename H0 into Hisr_prop_iret.
  rename H1 into Hgood_linv_iret.
  hoare unfold.
  inverts H.
  hoare forward.
  clear H0.
  rename H into H0.
  destruct H0.
  rename H into H0.
  unfold p_local in H0.
  sep normal in H0.
  unfold LINV in H0.
  unfold OSLInv in H0.
  sep split in H0.
  sep normal in H0.
  sep destruct H0.
  sep split in H0.
  destruct H11 as [Hv Hflag].
  inverts Hv.
  sep lift 2%nat in H0.
  apply disj_split in H0.
  destruct H0.
  sep normal in H0.
  sep destruct H0.
  sep split in H0;tryfalse.
  unfold IRINV.
  sep lift 2%nat.
  apply disj_split.
  left.
  unfold iret_ieon.
  unfold isr_inv.
  sep normal.
  exists (isrupd (isrupd ir 1%nat true) 1%nat false) (1%nat).
  assert (Hbase:
          s |= Aisr (isrupd (isrupd ir 1%nat true) 1%nat false) **
               Aie true ** Ais (1%nat :: v'4) **
               [| forall j : nat,
            (0 <= j < gettopis (OSToyISR :: v'4))%nat ->
            isrupd ir OSToyISR true j = false |] ** 
           PV get_off_addr ct ($ 24) @ Int8u |-r-> x ** CurTid ct).
  sep split;auto.
  sep auto.
  clear H0.
  sep cancel 5%nat 2%nat.
  sep cancel 5%nat 2%nat.
  clear -Hbase.
  split.
  split.
  sep auto.
  split.
  simpl.
  sep split in Hbase.
  split.
  rewrite H3;simpl;auto.
  simpl in Hbase;auto.
  sep split in Hbase.
  simpl.
  split.
  intros.
  simpl in H.
  unfold OSToyISR in *.
  simpl in H.
  apply H in H4.
  clear -H4.
  unfold isrupd in *.
  destruct (Nat.eqb 1 j);auto.
  unfolds in Hbase;auto.
  sep auto.
  sep split in H.
  unfolds in H;tryfalse.
  clear H0.
  rename H into H0.
  destruct H0.
  sep auto.
  sep split in H;unfolds in H;tryfalse.
  clear H0.
  rename H into H0.
  destruct H0.
  sep auto.
  sep split in H;unfolds in H;tryfalse.
  
  clear H0.
  rename H into H0.
  destruct H0.
  unfold OSToyISR.
  Require Import OSTimeTickPure.
  rewrite isrupd_true_false in H.
  sep auto.
  sep split in H;unfolds in H;tryfalse.
  clear H0.
  rename H into H0.
  destruct H0.
  sep auto.
  sep split in H;unfolds in H;tryfalse.
Qed.
