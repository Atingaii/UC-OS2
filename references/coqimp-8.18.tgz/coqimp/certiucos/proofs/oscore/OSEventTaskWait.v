(**************************  uc/OS-II  *******************************)
(*************************** OS_CORE.C *******************************)
(**Proof of Internal Fucntion: void OS_EventTaskWait(OS_EVENT* pevent) **)
(**************************** Code:***********************************)
(*
Void ·OS_EventTaskWait·(⌞pevent @ OS_EVENT∗⌟)··{
       ⌞ ⌟;

1       OSTCBCur′→OSTCBEventPtr =ₑ pevent′;ₛ
2       OSRdyTbl′[OSTCBCur′→OSTCBY] =ₑ 
                 OSRdyTbl′[OSTCBCur′→OSTCBY] &ₑ (∼OSTCBCur′→OSTCBBitX);ₛ
3       If (OSRdyTbl′[OSTCBCur′→OSTCBY] ==ₑ ′0)
        {
4           OSRdyGrp′ =ₑ OSRdyGrp′ &ₑ (∼OSTCBCur′→OSTCBBitY)
        };ₛ
5       pevent′→OSEventTbl[OSTCBCur′→OSTCBY] =ₑ 
               pevent′→OSEventTbl[OSTCBCur′→OSTCBY] |ₑ OSTCBCur′→OSTCBBitX;ₛ
6       pevent′→OSEventGrp =ₑ pevent′→OSEventGrp |ₑ OSTCBCur′→OSTCBBitY;ₛ
7       RETURN
}·. 
*)

(* Require Import ucert. *)
Require Import ucos_include.
Require Import OSETWaitPure.
Open Scope code_scope.


Lemma OSEventTaskWait_proof:
    forall tid vl p r ll, 
      Some p =
      BuildPreI os_internal OS_EventTaskWait
                  vl ll OS_EventTaskWaitPre tid ->
      Some r =
      BuildRetI os_internal OS_EventTaskWait vl ll OS_EventTaskWaitPost tid ->
      exists t d1 d2 s,
        os_internal OS_EventTaskWait = Some (t, d1, d2, s) /\
        {|OS_spec , GetHPrio, OSLInv, I, r, Afalse|}|- tid {{p}} s {{Afalse}}. 
Proof. 
  init_spec.
  hoare unfold.

  hoare forward.
  hoare unfold.


  lets Hi3: range_ostcby H.
  destruct Hi3 as [Hi3 Hi2].
  assert (Z.to_nat (Int.unsigned i3) < length v'0)%nat.
  {
    rewrite H8.
    unfold OS_RDY_TBL_SIZE.
    
    apply z_le_7_imp_n;auto.
    lia.
  }
  
  lets Hx: array_int8u_nth_lt_len H2 H12.
  Import DeprecatedTactic.
  mytac.
  hoare forward.
  go.
  (* simpl;splits;pauto. *)

  Import symbolic_lemmas.
  eapply array_type_vallist_match_imp_rule_type_val_match; eauto.
  struct_type_match_solver.
  discriminate.
  rewrite H27; simpl; discriminate.
  struct_type_match_solver.

  go.
  (* simpl;splits;pauto. *)
  unfold val_inj.
  unfold and.
  rewrite H27.
  auto.

  go.
  (* simpl;splits;pauto. *)
  unfold OS_RDY_TBL_SIZE.
  simpl Z.of_nat.
  auto.
  (*
  The second legacy goal was selected here.
  hoare lift 8%nat pre.
  apply backward_rule1 with Afalse.
  intros.

  sep remember (1::nil)%nat in H2.
  simpl in H2.
  mytac;auto.
  apply pfalse_rule.
   *)
  unfold AOSRdyGrp.
  hoare forward.
  (* simpl;splits;pauto. *)
  go.

  rewrite <- update_nth_val_length_eq.
  rewrite H8.
  unfold OS_RDY_TBL_SIZE.
  simpl Z.of_nat.
  auto.
  rewrite len_lt_update_get_eq.
  simpl.
  rtmatch_solve.
  apply int_lemma1;auto.
  rewrite H8.
  unfold OS_RDY_TBL_SIZE.
  simpl Z.of_nat.
  auto.
  rewrite len_lt_update_get_eq.
  simpl.
(* ** ac:   Locate "$". *)
  Local Open Scope int_scope.
  destruct (Int.eq (x&ᵢ Int.not i2) ($ 0));auto.
  discriminate.
  discriminate.
  apply Nat2Z.inj_lt in H12.
  rewrite Z2Nat.id in H12.
  exact H12.
  apply Int.unsigned_range_2.
  
  eapply forward_rule2.
  hoare forward.

  go.
  (* simpl;splits;pauto. *)
  unfold val_inj.
  unfold and.

  destruct v'1;tryfalse.
  auto.
  discriminate.
  all: try solve [destruct v'1; simpl in *; tryfalse; discriminate].
  intros.
  apply H29.
  apply disj_rule;pure intro.
  clear  H35 H33 H34.
  
  assert (Z.to_nat (Int.unsigned i3) < length v'4)%nat.
  rewrite H9.
  unfold OS_EVENT_TBL_SIZE.
  apply z_le_7_imp_n;auto.
  lia.
  lets Hx:array_int8u_nth_lt_len H4 H33.
  mytac.
  hoare forward.
  1: struct_type_match_solver.
  rewrite H34.
  apply true_if_else_true.
  apply Zle_is_le_bool.
  rewrite byte_max_unsigned_val.
  exact H35.
  1: struct_type_match_solver.
  1: rewrite H34; simpl; discriminate.
  1: struct_type_match_solver.
  1: eapply eq_int; auto.

  hoare forward.
  1: discriminate.
  1: struct_type_match_solver.
  1: struct_type_match_solver.
  1: discriminate.

  hoare forward.
  simpl;auto.
  simpl;auto.
  2:simpl;auto.
  2:auto.
  4:simpl;auto.
  5:auto.
  6:simpl;auto.
  splits;auto.
  1: {
    eapply nth_val'_imp_nth_val_int.
    exact H27.
  }
  1: {
    eapply nth_val'_imp_nth_val_int.
    exact H34.
  }
  1: {
    split.
    {
      rewrite H34.
      simpl; auto.
    }
    split; auto.
  }
  1: {
    split.
    {
      rewrite len_lt_update_get_eq in H30.
      assert (Int.eq (x &ᵢ Int.not i2) ($ 0) = true).
      {
        clear -H30.
        simpl in H30.
        simpl.
        destruct (Int.eq (x &ᵢ Int.not i2) ($ 0)); tryfalse; auto.
      }
      eapply event_wait_rl_tbl_grp'; eauto.
      rewrite H8.
      simpl; auto.
    }
    unfold and, val_inj.
    eapply idle_in_rtbl_hold; eauto.
  }
  1: {
    rtmatch_solve.
    apply int_lemma1; auto.
  }
  1: {
    split.
    {
      eapply array_type_vallist_match_int8u_update_hold; eauto.
      lia.
    }
    rewrite <- update_nth_val_length_eq.
    auto.
  }
  1: {
    split; auto.
    struct_type_match_solver.
  }
  1: {
    rewrite H34.
    eapply event_wait_rl_tbl_grp; eauto.
  }
  1: simpl; auto.
  1: {
    apply array_type_vallist_match_hold; auto.
    rewrite H34.
    rtmatch_solve.
    apply int_unsigned_or_prop; auto.
  }
  1: {
    simpl; splits; auto.
    rtmatch_solve.
    rtmatch_solve.
    apply int_unsigned_or_prop'; auto.
    pauto.
    pauto.
    pauto.
  }

  (*------------------------------*)
   
  assert (Z.to_nat (Int.unsigned i3) < length v'4)%nat.
  rewrite H9.
  unfold OS_EVENT_TBL_SIZE.
  apply z_le_7_imp_n;auto.
  lia.
  lets Hx:array_int8u_nth_lt_len H4 H31.
  mytac.
  hoare forward.
  1: struct_type_match_solver.
  rewrite H32.
  apply true_if_else_true.
  apply Zle_is_le_bool.
  rewrite byte_max_unsigned_val.
  exact H33.
  1: struct_type_match_solver.
  1: rewrite H32; simpl; discriminate.
  1: struct_type_match_solver.
  1: eapply eq_int; auto.

  hoare forward.
  1: discriminate.
  1: struct_type_match_solver.
  1: struct_type_match_solver.
  1: discriminate.

  hoare forward.
   simpl;auto.
  simpl;auto.
  2:simpl;auto.
  2:auto.
  4:simpl;auto.
  5:auto.
  6:simpl;auto.
  splits;auto.
  1: {
    eapply nth_val'_imp_nth_val_int.
    exact H27.
  }
  1: {
    eapply nth_val'_imp_nth_val_int.
    exact H32.
  }
  1: {
    split.
    {
      rewrite H32.
      simpl; auto.
    }
    split; auto.
  }
  1: {
    split.
    {
      rewrite len_lt_update_get_eq in H30.
      assert (Int.eq (x &ᵢ Int.not i2) ($ 0) = false).
      {
        clear -H30.
        simpl in H30.
        destruct H30.
        simpl in H.
        destruct (Int.eq (x &ᵢ Int.not i2) ($ 0)); tryfalse; auto.
        simpl in H.
        destruct (Int.eq (x &ᵢ Int.not i2) ($ 0)); tryfalse; auto.
      }
      eapply event_wait_rl_tbl_grp''; eauto.
      rewrite H8.
      simpl; auto.
    }
    unfold and, val_inj.
    eapply idle_in_rtbl_hold; eauto.
  }
  1: rtmatch_solve.
  1: {
    split.
    {
      eapply array_type_vallist_match_int8u_update_hold; eauto.
      lia.
    }
    rewrite <- update_nth_val_length_eq.
    auto.
  }
  1: {
    split; auto.
    struct_type_match_solver.
  }
  1: {
    rewrite H32.
    eapply event_wait_rl_tbl_grp; eauto.
  }
  1: simpl; auto.
  1: {
    apply array_type_vallist_match_hold; auto.
    rewrite H32.
    rtmatch_solve.
    apply int_unsigned_or_prop; auto.
  }
  1: {
    simpl; splits; auto.
    rtmatch_solve.
    rtmatch_solve.
    apply int_unsigned_or_prop'; auto.
    pauto.
    pauto.
    pauto.
  }

Qed.
