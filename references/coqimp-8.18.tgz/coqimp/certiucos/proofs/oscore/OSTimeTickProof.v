(**************************  uc/OS-II  *******************************)
(*************************** OS_CORE.C *******************************)
(********** Proof of Internal Fucntion: void OSTimeTick() ************)
(**************************** Code:***********************************)
(*
 Void ·OSTimeTick·(⌞ ⌟)··{
        ⌞ptcb @ OS_TCB∗;
         pevent @ OS_EVENT∗;
         ptbl @ Tptr Int8u⌟;
         
1        ++OSTime′;ₛ
2        ptcb′ =ₑ OSTCBList′;ₛ
3        WHILE (ptcb′ !=ₑ NULL)
         {
4          If (ptcb′→ OSTCBDly !=ₑ ′0)
           {
5               ptcb′→OSTCBDly =ₑ (ptcb′→OSTCBDly) − ′1;ₛ
6               If (ptcb′→OSTCBDly ==ₑ ′0)
                {
7                 OSRdyGrp′ =ₑ OSRdyGrp′ |ₑ ptcb′→OSTCBBitY;ₛ
8                OSRdyTbl′[ptcb′→OSTCBY] =ₑ OSRdyTbl′[ptcb′→OSTCBY] |ₑ ptcb′→OSTCBBitX;ₛ
9                 ptcb′→OSTCBStat =ₑ ′OS_STAT_RDY;ₛ
10                pevent′ =ₑ ptcb′→OSTCBEventPtr;ₛ
11                If (pevent′ !=ₑ NULL)
                 {
12                 ptbl′ =ₑ pevent′→OSEventTbl;ₛ
13                 ptbl′[ptcb′→OSTCBY] =ₑ 
                           ptbl′[ptcb′→OSTCBY] &ₑ (∼ptcb′→OSTCBBitX);ₛ
14                 If (ptbl′[ptcb′→OSTCBY] ==ₑ ′0)
                   {
15                    pevent′→OSEventGrp &=  ∼ptcb′→OSTCBBitY
                   };ₛ
16                 ptcb′→OSTCBEventPtr =ₑ NULL
                 }
               }
           };ₛ
17          ptcb′ =ₑ ptcb′→OSTCBNext
        };ₛ
18      RETURN
 }·.
*)
Require Import ucos_include.
Require Import OSTimeTickPure.
Require Import OSTimeDlyPure.
Require Import ucos_common.
Require Import oscore_common.
Require Import os_ucos_h.
Require Import symbolic_lemmas.
Require Import List.
Import DeprecatedTactic.
Open Scope code_scope.

Ltac split_right :=
  lazymatch goal with
  | |- _ /\ _ => split; [idtac | split_right]
  | _ => idtac
  end.

Ltac solve_byte_unsigned_leb :=
  lazymatch goal with
  | |- (if (Int.unsigned ?byte <=? Byte.max_unsigned)%Z
        then true else false) = true =>
      let Hbyte := fresh "Hbyte" in
      destruct (Z.leb (Int.unsigned byte) Byte.max_unsigned) eqn:Hbyte;
      [ reflexivity
      | simpl;
        apply Z.leb_gt in Hbyte;
        unfold Byte.max_unsigned, Byte.modulus in Hbyte;
        simpl in Hbyte;
        lia ]
  end.

Lemma timetick_update_range_from_split :
  forall (tcbls2 tcbls tcbls1 : TcbMod.map)
         (head : addrval) (rtbl : vallist)
         (left right prefix suffix : list vallist) (middle : val)
         (grp newgrp : int32) (event_head : val)
         (events new_events : list os_inv.EventCtr)
         (updated : list vallist) (new_rtbl : vallist),
    (left = nil /\ middle = Vptr head \/
       exists vl, left <> nil /\ last left nil = vl /\
                  nth_val 0 vl = Some middle) ->
    TcbMod.join tcbls1 tcbls2 tcbls ->
    TCBList_P (Vptr head) left rtbl tcbls1 ->
    TCBList_P middle right rtbl tcbls2 ->
    left ++ right = prefix ++ suffix ->
    array_type_vallist_match Int8u rtbl ->
    length rtbl = ∘ OS_RDY_TBL_SIZE ->
    (Int.unsigned grp <= 255)%Z ->
    RL_Tbl_Grp_P rtbl (Vint32 grp) ->
    tcbls_rtbl_timetci_update prefix rtbl (Vint32 grp) event_head events =
      Some (updated, new_rtbl, Vint32 newgrp, new_events) ->
    (Int.unsigned newgrp <= 255)%Z.
Proof.
  intros tcbls2 tcbls tcbls1 head rtbl left right prefix suffix middle
         grp newgrp event_head events new_events updated new_rtbl
         Hlink Hjoin Hleft Hright Hparts Harr Hlen Hgrp Hrl Hupdate.
  destruct
    (@tcblist_p_recombine tcbls2 tcbls head rtbl tcbls1
       left right middle prefix suffix Hlink Hjoin Hleft Hright Hparts)
    as [new_rtbl0 [new_tcbls Hprefix]].
  pose proof
    (@timetick_update_prop prefix rtbl grp updated new_rtbl newgrp
       event_head events new_events (Vptr head) new_rtbl0 new_tcbls
       Hprefix Harr Hlen Hgrp Hrl Hupdate) as Hprops.
  tauto.
Qed.

Lemma timetick_update_length_from_split :
  forall (tcbls2 tcbls tcbls1 : TcbMod.map)
         (head : addrval) (rtbl : vallist)
         (left right prefix suffix : list vallist) (middle : val)
         (grp newgrp : int32) (event_head : val)
         (events new_events : list os_inv.EventCtr)
         (updated : list vallist) (new_rtbl : vallist),
    (left = nil /\ middle = Vptr head \/
       exists vl, left <> nil /\ last left nil = vl /\
                  nth_val 0 vl = Some middle) ->
    TcbMod.join tcbls1 tcbls2 tcbls ->
    TCBList_P (Vptr head) left rtbl tcbls1 ->
    TCBList_P middle right rtbl tcbls2 ->
    left ++ right = prefix ++ suffix ->
    array_type_vallist_match Int8u rtbl ->
    length rtbl = ∘ OS_RDY_TBL_SIZE ->
    (Int.unsigned grp <= 255)%Z ->
    RL_Tbl_Grp_P rtbl (Vint32 grp) ->
    tcbls_rtbl_timetci_update prefix rtbl (Vint32 grp) event_head events =
      Some (updated, new_rtbl, Vint32 newgrp, new_events) ->
    length new_rtbl = ∘ OS_RDY_TBL_SIZE.
Proof.
  intros tcbls2 tcbls tcbls1 head rtbl left right prefix suffix middle
         grp newgrp event_head events new_events updated new_rtbl
         Hlink Hjoin Hleft Hright Hparts Harr Hlen Hgrp Hrl Hupdate.
  destruct
    (@tcblist_p_recombine tcbls2 tcbls head rtbl tcbls1
       left right middle prefix suffix Hlink Hjoin Hleft Hright Hparts)
    as [new_rtbl0 [new_tcbls Hprefix]].
  pose proof
    (@timetick_update_prop prefix rtbl grp updated new_rtbl newgrp
       event_head events new_events (Vptr head) new_rtbl0 new_tcbls
       Hprefix Harr Hlen Hgrp Hrl Hupdate) as Hprops.
  tauto.
Qed.

Lemma timetick_update_array_from_split :
  forall (tcbls2 tcbls tcbls1 : TcbMod.map)
         (head : addrval) (rtbl : vallist)
         (left right prefix suffix : list vallist) (middle : val)
         (grp newgrp : int32) (event_head : val)
         (events new_events : list os_inv.EventCtr)
         (updated : list vallist) (new_rtbl : vallist),
    (left = nil /\ middle = Vptr head \/
       exists vl, left <> nil /\ last left nil = vl /\
                  nth_val 0 vl = Some middle) ->
    TcbMod.join tcbls1 tcbls2 tcbls ->
    TCBList_P (Vptr head) left rtbl tcbls1 ->
    TCBList_P middle right rtbl tcbls2 ->
    left ++ right = prefix ++ suffix ->
    array_type_vallist_match Int8u rtbl ->
    length rtbl = ∘ OS_RDY_TBL_SIZE ->
    (Int.unsigned grp <= 255)%Z ->
    RL_Tbl_Grp_P rtbl (Vint32 grp) ->
    tcbls_rtbl_timetci_update prefix rtbl (Vint32 grp) event_head events =
      Some (updated, new_rtbl, Vint32 newgrp, new_events) ->
    array_type_vallist_match Int8u new_rtbl.
Proof.
  intros tcbls2 tcbls tcbls1 head rtbl left right prefix suffix middle
         grp newgrp event_head events new_events updated new_rtbl
         Hlink Hjoin Hleft Hright Hparts Harr Hlen Hgrp Hrl Hupdate.
  destruct
    (@tcblist_p_recombine tcbls2 tcbls head rtbl tcbls1
       left right middle prefix suffix Hlink Hjoin Hleft Hright Hparts)
    as [new_rtbl0 [new_tcbls Hprefix]].
  pose proof
    (@timetick_update_prop prefix rtbl grp updated new_rtbl newgrp
       event_head events new_events (Vptr head) new_rtbl0 new_tcbls
       Hprefix Harr Hlen Hgrp Hrl Hupdate) as Hprops.
  tauto.
Qed.

Lemma timetick_minus_in_range :
  forall i,
    (Int.unsigned i <= 65535)%Z ->
    val_inj
      (notint
         (val_inj
            (if Int.eq i ($ 0)
             then Some (Vint32 Int.one)
             else Some (Vint32 Int.zero)))) <> Vint32 Int.zero ->
    (Int.unsigned (i -ᵢ $ 1) <= Int16.max_unsigned)%Z.
Proof.
  intros i Hirange Hnonzero.
  assert (Heq : Int.eq i ($ 0) = false).
  {
    destruct (Int.eq i ($ 0)) eqn:Hi.
    2: reflexivity.
    simpl in Hnonzero.
    unfold Int.notbool in Hnonzero.
    rewrite eq_one_zero in Hnonzero.
    contradiction.
  }
  eapply ne_0_minus_1_in_range; eauto.
Qed.

Lemma timetick_sub_repr_range :
  forall i,
    (Int.unsigned i <= 65535)%Z ->
    val_inj
      (notint
         (val_inj
            (if Int.eq i ($ 0)
             then Some (Vint32 Int.one)
             else Some (Vint32 Int.zero)))) <> Vint32 Int.zero ->
    (0 <= Int.unsigned i - Int.unsigned ($ 1) <= Int.max_unsigned)%Z.
Proof.
  intros i Hirange Hnonzero.
  assert (Heq : Int.eq i ($ 0) = false).
  {
    destruct (Int.eq i ($ 0)) eqn:Hi.
    2: reflexivity.
    simpl in Hnonzero.
    unfold Int.notbool in Hnonzero.
    rewrite eq_one_zero in Hnonzero.
    contradiction.
  }
  pose proof (Int.eq_spec i ($ 0)) as Hspec.
  rewrite Heq in Hspec.
  assert (Hunsigned_ne : Int.unsigned i <> 0%Z).
  {
    intro Hu.
    apply Hspec.
    rewrite <- (Int.repr_unsigned i).
    rewrite Hu.
    reflexivity.
  }
  assert (Hone : Int.unsigned ($ 1) = 1%Z) by int auto.
  rewrite Hone.
  pose proof (Int.unsigned_range i) as Hirange_full.
  unfold Int.max_unsigned, Int.modulus.
  simpl.
  lia.
Qed.

Lemma timetick_tcb_flag_type_match :
  forall next prev event msg dly stat prio x y bitx bity,
    isptr next -> isptr prev -> isptr event -> isptr msg ->
    (Int.unsigned dly <= 65535)%Z ->
    (Int.unsigned stat <= 255)%Z ->
    (Int.unsigned prio <= 255)%Z ->
    (Int.unsigned x <= 255)%Z ->
    (Int.unsigned y <= 255)%Z ->
    (Int.unsigned bitx <= 255)%Z ->
    (Int.unsigned bity <= 255)%Z ->
    struct_type_vallist_match OS_TCB_flag
      (next :: prev :: event :: msg :: Vint32 dly :: Vint32 stat ::
       Vint32 prio :: Vint32 x :: Vint32 y :: Vint32 bitx ::
       Vint32 bity :: nil).
Proof.
  intros.
  unfold OS_TCB_flag, struct_type_vallist_match.
  simpl.
  repeat split.
  all: try solve [apply isptr_is_definitely_ptr; assumption].
  all: struct_single_condition_solver.
Qed.

Lemma timetick_event_type_match :
  forall etype grp cnt ptr tbl next,
    (Int.unsigned etype <= 255)%Z ->
    (Int.unsigned grp <= 255)%Z ->
    (Int.unsigned cnt <= 65535)%Z ->
    isptr ptr -> isptr next ->
    struct_type_vallist_match OS_EVENT
      (Vint32 etype :: Vint32 grp :: Vint32 cnt :: ptr :: tbl :: next :: nil).
Proof.
  intros.
  unfold OS_EVENT, struct_type_vallist_match.
  simpl.
  repeat split.
  all: try solve [apply isptr_is_definitely_ptr; assumption].
  all: struct_single_condition_solver.
Qed.

Lemma os_stat_rdy_compare_255 :
  (OS_STAT_RDY ?= 255)%Z = Gt -> False.
Proof.
  vm_compute.
  discriminate.
Qed.

Lemma os_stat_rdy_repr_range :
  (0 <= OS_STAT_RDY <= Int.max_unsigned)%Z.
Proof.
  vm_compute.
  split; discriminate.
Qed.

Lemma OSTimeTick_proof:
    forall vl p r logicl ct, 
      Some p =
      BuildPreI os_internal OSTimeTick
                  vl logicl OSTimeTickPre ct ->
      Some r =
      BuildRetI os_internal OSTimeTick vl logicl OSTimeTickPost ct ->
      exists t d1 d2 s,
        os_internal OSTimeTick = Some (t, d1, d2, s) /\
        {|OS_spec , GetHPrio, OSLInv, I, r, Afalse|}|-ct {{p}} s {{Afalse}}. 
Proof.
  init spec.
  unfold OSTimeTickPre'.
  unfold AOSRdyTblGrp.
  unfold AOSRdyTbl.
  unfold AOSRdyGrp.
  unfold AECBList.
  pure_intro'.
  rename v'20 into vcode.
  rename v'23 into v'20.
  rename H10 into Hidle.
  rename H11 into H10.
  hoare forward.
  (* intro;tryfalse. *)
  discriminate.
  hoare forward.
  eapply backward_rule1.
  intros.
  sep lifts (12::14::nil)%nat in H.

  eapply tcbdllseg_compose' in H.
  exact H.
  pure_intro'.
  remember (v'5 ++ v'6 :: v'7) as tcbl.
  apply backward_rule1 with (p:=
  EX tail1 tcbl1 tcbl2 x tcbl1' rtbl' rgrp' ectrl' v'0 v'1,
     [| tcbl = tcbl1 ++ tcbl2|] **
     tcbdllseg (Vptr v'4) Vnull tail1 x tcbl1' **
     tcbdllseg x tail1 v'12 Vnull tcbl2 **
     evsllseg v'20 Vnull ectrl' v'17 **
     [| tcbls_rtbl_timetci_update tcbl1 v'8 (Vint32 i) v'20 v'16= Some (tcbl1',rtbl',Vint32 rgrp',ectrl')|] **
     <|| vcode ||>  **
     LV ptcb @ OS_TCB ∗ |-> x **
     LV pevent @ OS_EVENT ∗ |-> v'0 **
     LV ptbl @ (Int8u) ∗ |-> v'1 **
     A_dom_lenv ((ptcb, OS_TCB ∗) :: (pevent, OS_EVENT ∗) ::  (ptbl, (Int8u) ∗) :: nil)  **
     GV OSEventList @ OS_EVENT ∗ |-> v'20 **
     GV OSTime @ Int32u |-> Vint32 (Int.add v'10 Int.one) **
     Aisr (isrupd v'2 0%nat false) **
     Aie false **
     Ais (0%nat :: v'3) **
     Acs nil **
     GV OSTCBList @ OS_TCB ∗ |-> Vptr v'4 **
     GV OSTCBCur @ OS_TCB ∗ |-r-> Vptr ct **
     GAarray OSRdyTbl (Tarray Int8u ∘OS_RDY_TBL_SIZE) rtbl' **
     GV OSRdyGrp @ Int8u |-> Vint32 rgrp' ** p_local OSLInv ct (logic_val v'22 :: nil)).
  intros.
  exists Vnull (nil:list vallist) tcbl (Vptr v'4) (nil:list vallist).
  exists v'8 i v'16 v'0 v'1.

  sep semiauto.
  unfold tcbdllseg at 1.
  unfold dllseg.
  sep auto.
  
  eapply seq_rule.
  eapply while_rule.
  intros.

  sep normal in H11.
  sep destruct H11.
  sep lift 3%nat in H11.
  unfold tcbdllseg in H11.
  lets Hisptr: dllseg_head_isptr H11.

  symbolic execution;pauto.
  2: {
  pure_intro'.
  eapply backward_rule1.
  intros.
  destruct H11.

  sep lift 6%nat in H11.
  lets Hx:neq_null_false_elim H11 H12.
  subst v'25.

  instantiate (1:= LV ptcb @ OS_TCB ∗ |-> Vnull **
           tcbdllseg (Vptr v'4) Vnull v'9 Vnull v'26 **
           tcbdllseg Vnull v'9 v'12 Vnull v'24 **
           evsllseg v'20 Vnull v'29 v'17 **
           [|tcbls_rtbl_timetci_update v'23 v'8 (Vint32 i) v'20 v'16 =
             Some (v'26, v'27, Vint32 v'28, v'29)|] **
            <|| vcode ||>  **
           LV pevent @ OS_EVENT ∗ |-> v'30 **
           LV ptbl @ (Int8u) ∗ |-> v'31 **
           A_dom_lenv
             ((ptcb, OS_TCB ∗)
              :: (pevent, OS_EVENT ∗) :: (ptbl, (Int8u) ∗) :: nil) **
           GV OSEventList @ OS_EVENT ∗ |-> v'20 **
           GV OSTime @ Int32u |-> Vint32 (v'10 +ᵢ  Int.one) **
           Aisr (isrupd v'2 0%nat false) **
           Aie false **
           Ais (0%nat :: v'3) **
           Acs nil **
           GV OSTCBList @ OS_TCB ∗ |-> Vptr v'4 **
           GV OSTCBCur @ OS_TCB ∗ |-r-> Vptr ct **
           GAarray OSRdyTbl (Tarray Int8u ∘ OS_RDY_TBL_SIZE) v'27 **
           GV OSRdyGrp @ Int8u |-> Vint32 v'28 **
           p_local OSLInv ct (logic_val v'22 :: nil) **
           [|v'5 ++ v'6 :: v'7 = v'23 ++ v'24|]).
  auto.
  unfold OSTimeTickPost'.
  unfold tcbdllseg at 3.

  eapply backward_rule1.
  intros.
  sep lift 3%nat in H11.
  lets Hx:dllseg_head_null_elim H11.
  destruct Hx;subst.
  instantiate (1:=
       LV ptcb @ OS_TCB ∗ |-> Vnull **
           tcbdllseg (Vptr v'4) Vnull v'12 Vnull v'26 **
           evsllseg v'20 Vnull v'29 v'17 **
           [|tcbls_rtbl_timetci_update v'23 v'8 (Vint32 i) v'20 v'16 =
             Some (v'26, v'27, Vint32 v'28, v'29)|] **
            <|| vcode ||>  **
           LV pevent @ OS_EVENT ∗ |-> v'30 **
           LV ptbl @ (Int8u) ∗ |-> v'31 **
           A_dom_lenv
             ((ptcb, OS_TCB ∗)
              :: (pevent, OS_EVENT ∗) :: (ptbl, (Int8u) ∗) :: nil) **
           GV OSEventList @ OS_EVENT ∗ |-> v'20 **
           GV OSTime @ Int32u |-> Vint32 (v'10+ᵢ Int.one) **
           Aisr (isrupd v'2 0%nat false) **
           Aie false **
           Ais (0%nat :: v'3) **
           Acs nil **
           GV OSTCBList @ OS_TCB ∗ |-> Vptr v'4 **
           GV OSTCBCur @ OS_TCB ∗ |-r-> Vptr ct **
           GAarray OSRdyTbl (Tarray Int8u ∘OS_RDY_TBL_SIZE) v'27 **
           GV OSRdyGrp @ Int8u |-> Vint32 v'28 **
           p_local OSLInv ct (logic_val v'22 :: nil) **
           [|v'5 ++ v'6 :: v'7 = v'23 ++ nil|]).
  simpl dllseg in H11.
  sep semiauto.
  pure_intro'.
  rewrite List.app_nil_r in H12;subst.
  apply ret_rule'.
  intros.
  sep normal.
  sep eexists.
  sep normal in H12.
  sep split in H12.
  sep split.
  21: { auto. }
  sep semiauto.
  sep lift 2%nat;eauto.
  auto.
  auto.
  auto.
  auto.
  auto.
  auto.
  auto.
  eapply timetick_idle_in_rtbl;eauto.
  eapply TCBList_P_imp_RL;eauto.
  eapply OSQPostPure.TCBList_P_Combine;eauto.
  clear -H.
  destruct H.
  mytac;subst;simpl;auto.
  inverts H0.
  auto.
  mytac.
  unfolds.
  destruct v'5;tryfalse;simpl;auto.
  auto.
  auto.
  auto.
  auto.
  auto.
  auto.
  auto.
  eauto.
  auto.
  auto.
  auto.
  }
  (* while body *)
  remember (
    logic_isr v'2
      :: logic_is v'3
         :: logic_val (Vint32 v'10)
            :: logic_val (Vptr v'4)
               :: logic_val (Vptr v'4)
                  :: logic_llv v'5
                     :: logic_lv v'6
                        :: logic_llv v'7
                           :: logic_lv v'8
                              :: logic_val (Vint32 i)
                                 :: logic_val v'11
                                    :: logic_val v'12
                                       :: logic_abstcb v'13
                                          :: logic_abstcb v'14
                                             :: logic_abstcb v'15
                                                :: 
                                                logic_leventc v'16
                                                :: 
                                                logic_leventd v'17
                                                :: 
                                                logic_absecb v'18
                                                :: 
                                                logic_code vcode
                                                :: 
                                                logic_val (Vptr v'21)
                                                :: 
                                                logic_val v'22 :: nil) as ll.
  clear Heqll.
  
  pure_intro'.

  eapply backward_rule1.
  intros.
  destruct H11.
  sep lift 6%nat in H11.
  lets Hx:neq_null_true_elim H11 H12.
  instantiate (1:=LV ptcb @ OS_TCB ∗ |-> v'25 **
           tcbdllseg (Vptr v'4) Vnull v'9 v'25 v'26 **
           tcbdllseg v'25 v'9 v'12 Vnull v'24 **
           evsllseg v'20 Vnull v'29 v'17 **
           [|tcbls_rtbl_timetci_update v'23 v'8 (Vint32 i) v'20 v'16 =
             Some (v'26, v'27, Vint32 v'28, v'29)|] **
            <|| vcode ||>  **
           LV pevent @ OS_EVENT ∗ |-> v'30 **
           LV ptbl @ (Int8u) ∗ |-> v'31 **
           A_dom_lenv
             ((ptcb, OS_TCB ∗)
              :: (pevent, OS_EVENT ∗) :: (ptbl, (Int8u) ∗) :: nil) **
           GV OSEventList @ OS_EVENT ∗ |-> v'20 **
           GV OSTime @ Int32u |-> Vint32 (v'10 +ᵢ  Int.one) **
           Aisr (isrupd v'2 0%nat false) **
           Aie false **
           Ais (0%nat :: v'3) **
           Acs nil **
           GV OSTCBList @ OS_TCB ∗ |-> Vptr v'4 **
           GV OSTCBCur @ OS_TCB ∗ |-r-> Vptr ct **
           GAarray OSRdyTbl (Tarray Int8u ∘ OS_RDY_TBL_SIZE) v'27 **
           GV OSRdyGrp @ Int8u |-> Vint32 v'28 **
           p_local OSLInv ct (logic_val v'22 :: nil) **
           [|v'5 ++ v'6 :: v'7 = v'23 ++ v'24|] ** [| v'25 <> Vnull |]).
  clear H12.
  sep semiauto.
  pure_intro'.
  destruct v'24.
  unfold tcbdllseg at 3.
  unfold dllseg.
  pure_intro'.
  tryfalse.
  hoare lift 3%nat pre.
  unfold tcbdllseg at 2.
  unfold dllseg;fold dllseg.
  unfold node.

  pure_intro'.
  
  hoare forward.
  (* intro;tryfalse. *)
  go.
  destruct (Int.eq i6 ($ 0));simpl;intro;tryfalse.

  struct_type_match_solver.
  unfold notint, val_inj.
  destruct (Int.eq i6 ($ 0)); simpl; discriminate.
  destruct (Int.eq i6 ($ 0)); simpl; discriminate.
  hoare forward.
  (* intro;tryfalse. *)
  go.
  (* intro;tryfalse. *)
  discriminate.
  struct_type_match_solver.
  intro Hdefined; discriminate Hdefined.
  hoare forward.
  (* intro;tryfalse. *)
  discriminate.
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  rtmatch_solve.
  eapply ne_0_minus_1_in_range;eauto.
  destruct H16.
  destruct (Int.eq i6  ($ 0)).
  
  simpl in H16.
  unfold Int.notbool in H16.
  rewrite eq_one_zero in H16.
  tryfalse.
  auto.
  pauto.
  rtmatch_solve.
  split_right; pauto.
  pauto.
  (* destruct (Int.eq (i6 -ᵢ $ 1) ($ 0));simpl;intro;tryfalse. *)
  lets Hx: tcblist_p_recombine H0 H1 H2 H12;auto.
  destruct Hx as [rtbl_prefix [tcbls_prefix Htcb_prefix]].
  pose proof
    (@timetick_update_prop v'23 v'8 i v'26 v'27 v'28 v'20 v'16 v'29
       (Vptr v'4) rtbl_prefix tcbls_prefix Htcb_prefix H6 H10 H7 H8 H11)
    as Hx.

  
  mytac.
  all: try solve [pauto].
  destruct (Int.eq (i6 -ᵢ $ 1) ($ 0)); simpl; discriminate.
  hoare forward.
  rtmatch_solve.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  apply (proj2 (Z.compare_le_iff _ _)).
  eapply timetick_update_range_from_split
    with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
         (head := v'4) (rtbl := v'8) (left := v'5)
         (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
         (grp := i) (newgrp := v'28) (event_head := v'20)
         (events := v'16) (new_events := v'29)
         (updated := v'26) (new_rtbl := v'27); eauto.
  discriminate.
  struct_type_match_solver.
  exfalso.
  destruct H16 as [Hnz _].
  pose proof (timetick_minus_in_range i6 H21 Hnz) as Hminus_range.
  lia.
  discriminate.

  lets Hrltcbblk: tcbnode_rl_prop H0 H1 H2 H12.
  lets Hi2:rl_tcbblk_tcby_range Hrltcbblk.
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  discriminate.
  struct_type_match_solver.
  exfalso.
  destruct H16 as [Hnz _].
  pose proof (timetick_minus_in_range i6 H21 Hnz) as Hminus_range.
  lia.
  apply (proj2 (Z.compare_lt_iff _ _)).
  assert (Hnew_len : length v'27 = ∘ OS_RDY_TBL_SIZE).
  {
    eapply timetick_update_length_from_split
      with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
           (head := v'4) (rtbl := v'8) (left := v'5)
           (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
           (grp := i) (newgrp := v'28) (event_head := v'20)
           (events := v'16) (new_events := v'29)
           (updated := v'26) (new_rtbl := v'27); eauto.
  }
  rewrite Hnew_len.
  exact Hi2.
  eapply array_type_vallist_match_imp_rule_type_val_match.
  apply ge0_z_nat_le.
  lets Hx: Int.unsigned_range i2.
  lia.
  assert (Hnew_len' : length v'27 = ∘ OS_RDY_TBL_SIZE).
  {
    eapply timetick_update_length_from_split
      with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
           (head := v'4) (rtbl := v'8) (left := v'5)
           (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
           (grp := i) (newgrp := v'28) (event_head := v'20)
           (events := v'16) (new_events := v'29)
           (updated := v'26) (new_rtbl := v'27); eauto.
  }
  rewrite Hnew_len'.
  exact Hi2.
  eapply timetick_update_array_from_split
    with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
         (head := v'4) (rtbl := v'8) (left := v'5)
         (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
         (grp := i) (newgrp := v'28) (event_head := v'20)
         (events := v'16) (new_events := v'29)
         (updated := v'26) (new_rtbl := v'27); eauto.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  discriminate.
  struct_type_match_solver.
  exfalso.
  destruct H16 as [Hnz _].
  pose proof (timetick_minus_in_range i6 H21 Hnz) as Hminus_range.
  lia.
  assert (Hrule :
    rule_type_val_match Int8u
      (nth_val' (Z.to_nat (Int.unsigned i2)) v'27) = true).
  {
    eapply array_type_vallist_match_imp_rule_type_val_match.
    apply ge0_z_nat_le.
    lets Hx: Int.unsigned_range i2.
    lia.
    assert (Hnew_len : length v'27 = ∘ OS_RDY_TBL_SIZE).
    {
      eapply timetick_update_length_from_split
        with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
             (head := v'4) (rtbl := v'8) (left := v'5)
             (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
             (grp := i) (newgrp := v'28) (event_head := v'20)
             (events := v'16) (new_events := v'29)
             (updated := v'26) (new_rtbl := v'27); eauto.
    }
    rewrite Hnew_len.
    exact Hi2.
    eapply timetick_update_array_from_split
      with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
           (head := v'4) (rtbl := v'8) (left := v'5)
           (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
           (grp := i) (newgrp := v'28) (event_head := v'20)
           (events := v'16) (new_events := v'29)
           (updated := v'26) (new_rtbl := v'27); eauto.
  }
  simpl in Hrule.
  destruct (nth_val' (Z.to_nat (Int.unsigned i2)) v'27);tryfalse.
  simpl;auto.
  (* intro;tryfalse. *)
  (* intro;tryfalse. *)

  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_or; discriminate Hbad_or.
  discriminate.
  eapply timetick_tcb_flag_type_match; eauto.
  eapply timetick_minus_in_range; eauto.
  exact (proj1 H16).
  apply (proj2 (Z.compare_lt_iff _ _)).
  exact Hi2.
  apply (proj2 (Z.compare_lt_iff _ _)).
  assert (Hnew_len : length v'27 = ∘ OS_RDY_TBL_SIZE).
  {
    eapply timetick_update_length_from_split
      with (tcbls2 := v'15) (tcbls := v'13) (tcbls1 := v'14)
           (head := v'4) (rtbl := v'8) (left := v'5)
           (right := v'6 :: v'7) (prefix := v'23) (middle := Vptr v'21)
           (grp := i) (newgrp := v'28) (event_head := v'20)
           (events := v'16) (new_events := v'29)
           (updated := v'26) (new_rtbl := v'27); eauto.
  }
  rewrite Hnew_len.
  exact Hi2.
  hoare forward.
  
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_struct; discriminate Hbad_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  eapply timetick_minus_in_range; eauto.
  exact (proj1 H16).
  int auto.
  pauto.
  pauto.
  split_right; pauto.
  all: try exact os_stat_rdy_compare_255.
  all: try solve [eapply timetick_sub_repr_range; eauto].
  all: try exact os_stat_rdy_repr_range.

  hoare_assert_pure (vl_elem_neq (get_eid_list v'20 v'29)).
  rename H15 into Hstate_evs.
  sep lift 10%nat in Hstate_evs.
  eapply evsllseg_eid_neq;eauto.
  pure_intro'.
  match goal with
  | Hneq : vl_elem_neq (get_eid_list v'20 v'29) |- _ =>
      rename Hneq into Heidneq
  end.
  evar (tick_event_post : asrt).
  eapply forward_rule2 with (q' := tick_event_post).
  hoare forward.
  pauto.
  pauto.
  pauto.
  instantiate
    (tick_event_post := EX ectrl' vx,
         <|| vcode ||>  **
             LV pevent @ OS_EVENT ∗ |-> x7 **
             LV ptcb @ OS_TCB ∗ |-> Vptr (v'33, Int.zero) **
             Astruct (v'33, Int.zero) OS_TCB_flag
             (v'32
         :: v'9
            :: Vnull
               :: x6
                  :: Vint32 (i6 -ᵢ $ 1)
                     :: V$ OS_STAT_RDY
                        :: Vint32 i4
                           :: Vint32 i3
                              :: Vint32 i2 :: Vint32 i1 :: Vint32 i0 :: nil) **
             A_dom_lenv
             ((ptcb, OS_TCB ∗) :: (pevent, OS_EVENT ∗) :: (ptbl, (Int8u) ∗) :: nil) **
             GAarray OSRdyTbl (Tarray Int8u ∘OS_RDY_TBL_SIZE)
             (update_nth_val (Z.to_nat (Int.unsigned i2)) v'27
                             (val_inj
                                (or (nth_val' (Z.to_nat (Int.unsigned i2)) v'27) (Vint32 i1)))) **
             GV OSRdyGrp @ Int8u |-> Vint32 (Int.or v'28 i0) **
             dllseg v'32 (Vptr (v'33, Int.zero)) v'12 Vnull v'24 OS_TCB_flag
             (fun vl : vallist => nth_val 1 vl) (fun vl : vallist => nth_val 0 vl) **
             tcbdllseg (Vptr v'4) Vnull v'9 (Vptr (v'33, Int.zero)) v'26 **
             [|tick_rdy_ectr  (v'32
         :: v'9
            :: x7
               :: x6
                  :: Vint32 (i6 -ᵢ $ 1)
                     :: V$ OS_STAT_RDY
                        :: Vint32 i4
                           :: Vint32 i3
                              :: Vint32 i2 :: Vint32 i1 :: Vint32 i0 :: nil) v'20 v'29 = Some ectrl'|] **
             evsllseg v'20 Vnull ectrl' v'17 **
             LV ptbl @ (Int8u) ∗ |-> vx **
             GV OSEventList @ OS_EVENT ∗ |-> v'20 **
             GV OSTime @ Int32u |-> Vint32 (v'10+ᵢ Int.one) **
             Aisr (isrupd v'2 0%nat false) **
             Aie false **
             Ais (0%nat :: v'3) **
             Acs nil **
             GV OSTCBList @ OS_TCB ∗ |-> Vptr v'4 ** GV OSTCBCur @ OS_TCB ∗ |-r-> Vptr ct **
      p_local OSLInv ct (logic_val v'22 :: nil)).
  pure_intro'.
  match goal with
  | Hisptr : isptr x7 |- _ => rename Hisptr into Hx7_isptr
  end.
  unfolds in Hx7_isptr.
  destruct Hx7_isptr as [Hx7null | Hx7ptr].
  - subst x7.
    match goal with
    | Hguard : val_inj (notint (val_inj (val_eq Vnull Vnull))) <>
        Vint32 Int.zero |- _ =>
        exfalso; apply Hguard; vm_compute; reflexivity
    end.
  - destruct Hx7ptr as [event_addr Hx7].
  destruct event_addr as [event_block event_offset].
  subst x7.

  lets Hx': tcb_eptr_get_ectr H0 H1 H2 H12 H5.
  lets Hx: Hx' H3 H10;eauto.
  clear -Hrltcbblk.
  unfolds in Hrltcbblk.
  mytac.
  unfolds in H;simpl in H;inverts H.
  auto.
  unfolds in H;simpl in H;inverts H.
  auto.
  clear Hx'.
  mytac.
  match goal with
  | Hget : get_ectr (Vptr (event_block, event_offset)) v'20 v'29 = Some _ |- _ =>
      rename Hget into Hget_event
  end.
  assert (Hstatus_range : (Int.unsigned i5 <= 255)%Z) by auto.

  eapply backward_rule1.
  intros st Hstate.

  sep lift 10%nat in Hstate.
  lets Hx: get_ectr_decompose Hstate Hget_event.
  exact Hx.
  pure_intro'.
  match goal with
  | Hnone : get_ectr _ _ ?prefix = None |- _ =>
      rename Hnone into Hgetl1none
  end.
  match goal with
  | Hlast : get_ectr _ _ (?prefix ++ _) = Some _ |- _ =>
      rename Hlast into Hgetl2last
  end.
  match goal with
  | Hnonnull : v'20 <> Vnull |- _ =>
      rename Hnonnull into Hpnovnull
  end.
  unfold AEventNode.

  unfold AOSEvent.
  unfold node.
  unfold AOSEventTbl.
  pure_intro'.
  match goal with
  | Harray : array_type_vallist_match Int8u x0 |- _ =>
      rename Harray into Hevent_array_type
  end.
  match goal with
  | Hlen : length x0 = ∘ OS_EVENT_TBL_SIZE |- _ =>
      rename Hlen into Hevent_array_len
  end.
  
  assert (exists ready_byte,
      nth_val' (Z.to_nat (Int.unsigned i2)) x0 = Vint32 ready_byte /\
      (Int.unsigned ready_byte <= 255)%Z).
  eapply array_int8u_nth_lt_len;eauto.
  rewrite Hevent_array_len;simpl.
  unfold Pos.to_nat.
  unfold Pos.iter_op.
  simpl.
  apply z_le_7_imp_n;auto.
  lia.
  mytac.
  match goal with
  | Hnth : nth_val' (Z.to_nat (Int.unsigned i2)) x0 = Vint32 ?ready,
    Hrange : (Int.unsigned ?ready <= 255)%Z |- _ =>
      rename Hnth into Hevent_ready_nth;
      rename Hrange into Hevent_ready_range
  end.

  hoare forward.
  simpl in H38;eauto.
 
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_struct; discriminate Hbad_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  right; eexists; reflexivity.
  eapply timetick_minus_in_range; eauto.
  pauto.
  pauto.
  split_right; pauto.
   
  vm_compute; discriminate.
  rewrite Hevent_array_len.
  unfold OS_EVENT_TBL_SIZE.
  simpl.
  auto.
  rewrite Hevent_ready_nth.
  rtmatch_solve.
  intro Hbad_array_struct; discriminate Hbad_array_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  right; eexists; reflexivity.
  eapply timetick_minus_in_range; eauto.
  vm_compute; discriminate.
  discriminate.
  rewrite Hevent_ready_nth; simpl; discriminate.
  intro Hbad_array_struct; discriminate Hbad_array_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  right; eexists; reflexivity.
  eapply timetick_minus_in_range; eauto.
  vm_compute; discriminate.
  eapply assign_type_match_true;simpl;auto.
  rewrite Hevent_array_len.
  unfold OS_EVENT_TBL_SIZE.
  simpl.
  auto.
  
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_array_struct; discriminate Hbad_array_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  right; eexists; reflexivity.
  eapply timetick_minus_in_range; eauto.
  vm_compute; discriminate.
  pauto.
  pauto.
  split_right; pauto.
   
  rewrite update_nth_val_len_eq.
  rewrite Hevent_array_len.
  unfold OS_EVENT_TBL_SIZE.
  simpl.
  auto.
  rewrite Hevent_ready_nth.
  rewrite len_lt_update_get_eq.
  rtmatch_solve.
  eapply int_lemma1;eauto.
  rewrite Hevent_array_len.
  unfold OS_EVENT_TBL_SIZE.
  simpl;auto.
  rewrite Hevent_ready_nth.
  rewrite len_lt_update_get_eq.
  unfold val_inj.
  unfold and.
  unfold val_eq.
  destruct (Int.eq (x &ᵢ Int.not i1) ($ 0)); simpl; try discriminate.
  (* intro;tryfalse. *)
  (* intro;tryfalse. *)
  rewrite Hevent_array_len.
  unfold OS_EVENT_TBL_SIZE.
  simpl.
  auto.
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right; pauto.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_array_struct; discriminate Hbad_array_struct.
  eapply timetick_event_type_match; eauto.
  pauto.
  pauto.
  split_right; pauto.
  (* intro;tryfalse. *)
  (* intro;tryfalse. *)
  intro Hbad_array_struct; discriminate Hbad_array_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  right; eexists; reflexivity.
  eapply timetick_minus_in_range; eauto.
  vm_compute; discriminate.
  discriminate.
  discriminate.
  eapply disj_rule.
  pure_intro'.
  match goal with
  | Hcond : val_inj
      (val_eq (nth_val' _ (update_nth_val _ _ _)) _) <>
      Vint32 Int.zero |- _ =>
      rename Hcond into Hevent_nonzero
  end.
  rewrite len_lt_update_get_eq in Hevent_nonzero.
  rewrite Hevent_ready_nth in Hevent_nonzero.
  unfold and in Hevent_nonzero.
  unfold val_eq, val_inj in Hevent_nonzero.
  assert (Hevent_byte_zero : Int.eq (x &ᵢ Int.not i1) ($ 0) = true).
  {
    destruct (Int.eq (x &ᵢ Int.not i1) ($ 0)) eqn:Heq; auto.
  }
  clear Hevent_nonzero.
  hoare forward.
  2: {
    apply Z.compare_lt_iff.
    rewrite Hevent_array_len.
    unfold OS_EVENT_TBL_SIZE.
    simpl.
    lia.
  }
  Unshelve.
  3: { exact tick_event_post. }
  hoare forward.
  {
  unfold tick_event_post.
  exists (v'34++ (((Vint32 i8
              :: Vint32 (i7&ᵢ Int.not i0)
                 :: Vint32 i9 :: x4 :: x5 :: v'25 :: nil),
                (update_nth_val (Z.to_nat (Int.unsigned i2)) x0
                  (val_inj
                    (and (nth_val' (Z.to_nat (Int.unsigned i2)) x0)
                         (Vint32 (Int.not i1))))))::nil) ++ v'35).
  sep eexists.
  sep lift 11%nat.
  eapply evsllseg_compose;eauto.
  unfolds;simpl;auto.
  unfold AEventNode.
  unfold AOSEvent.
  unfold AOSEventTbl.
  unfold node.
  
          
  sep semiauto;eauto.
  2:unfolds;simpl;auto.
  {
    simpl.
    rewrite Hevent_ready_nth.
    unfold and,val_inj.
    eapply tick_rdy_ectr_imp;eauto.
  }
  rewrite Hevent_ready_nth.
  unfold and.
  simpl val_inj.
  eapply event_wait_rl_tbl_grp';eauto.
  unfolds;simpl;auto.
  rewrite Hevent_ready_nth.
  unfold and,val_inj.

  eapply array_type_vallist_match_int8u_update_hold_255;eauto.
  lia.
  simpl; split_right; auto.
  rtmatch_solve.
  rtmatch_solve.
  apply int_lemma1;auto.
  pauto.
  pauto.
  pauto.
  }

  pure_intro'.
  match goal with
  | Hcond : val_inj
      (val_eq (nth_val' _ (update_nth_val _ _ _)) _) =
      Vint32 Int.zero \/ _ |- _ =>
      rename Hcond into Hevent_zero
  end.
  rewrite len_lt_update_get_eq in Hevent_zero.
  rewrite Hevent_ready_nth in Hevent_zero.
  unfold and in Hevent_zero.
  unfold val_eq, val_inj in Hevent_zero.
  remember (Int.eq (x &ᵢ Int.not i1) ($ 0)) as X.
  destruct Hevent_zero as [Hevent_eq_zero | Hevent_eq_null].
  2: { destruct X; simpl in Hevent_eq_null; tryfalse. }
  destruct X; simpl in Hevent_eq_zero; tryfalse.
  try clear Hevent_eq_zero.
  hoare forward.
  2: {
    rewrite Hevent_array_len.
    unfold OS_EVENT_TBL_SIZE.
    simpl.
    lia.
  }
  {
  unfold tick_event_post.
  exists (v'34++ (((Vint32 i8
              :: Vint32 i7
                 :: Vint32 i9 :: x4 :: x5 :: v'25 :: nil), (update_nth_val (Z.to_nat (Int.unsigned i2)) x0
                (val_inj
                   (and (nth_val' (Z.to_nat (Int.unsigned i2)) x0)
                        (Vint32 (Int.not i1))))))::nil) ++ v'35).
  sep eexists.
  sep lift 11%nat.
  eapply evsllseg_compose;eauto.
  unfolds;simpl;auto.
  unfold AEventNode.
  unfold AOSEvent.
  unfold AOSEventTbl.
  unfold node.
  sep semiauto;eauto.
  instantiate (1:=v'39).
  sep auto.
  {
    simpl.
    rewrite Hevent_ready_nth.
    unfold and,val_inj.
    eapply tick_rdy_ectr_imp';eauto.
  }
  rewrite Hevent_ready_nth.
  eapply event_wait_rl_tbl_grp'';eauto.
  unfolds;simpl;auto.
  rewrite Hevent_ready_nth.
  unfold and,val_inj.

  eapply array_type_vallist_match_int8u_update_hold_255;eauto.
  lia.
  simpl; split_right; auto.
  rtmatch_solve.
  pauto.
  pauto.
  pauto.
  pauto.

  }
  - intros.
  match goal with
  | Hstate : s |= _ |- s |= _ => rename Hstate into Hbranch_state
  end.
  destruct Hbranch_state as [Hbranch_null | Hbranch_nonnull].
  + sep auto.
  + sep split in Hbranch_nonnull.
    match goal with
    | Hcond : val_inj (notint (val_inj (val_eq x7 Vnull))) =
        Vint32 Int.zero \/ _ = Vnull |- _ =>
        rename Hcond into Hx7_null_condition
    end.
    assert (Hx7null : x7 = Vnull).
    {
      clear -Hx7_null_condition H19.
      unfolds in H19.
      destruct H19; auto.
      mytac.
      destruct Hx7_null_condition; destruct x;
        unfold val_eq, val_inj, notint in H; tryfalse.
    }
    subst x7.
    unfold tick_event_post.
    exists v'29.
    exists v'31.
    sep auto.
  
  - apply disj_rule.
  pure_intro'.
  apply disj_rule.
  pure_intro'.
  match goal with
  | Hguard : val_inj
      (notint
        (val_inj
          (if Int.eq i6 ($ 0)
           then Some (Vint32 Int.one)
           else Some (Vint32 Int.zero)))) <> Vint32 Int.zero |- _ =>
      rename Hguard into Hi6_nonzero_guard
  end.
  assert (Hi6_nonzero : Int.eq i6 ($ 0) = false).
  {
    destruct (Int.eq i6 ($ 0)); simpl in Hi6_nonzero_guard.
    - exfalso.
      apply Hi6_nonzero_guard.
      f_equal.
    - reflexivity.
  }
  match goal with
  | Hguard : val_inj
      (if Int.eq (i6-ᵢ$ 1) ($ 0)
       then Some (Vint32 Int.one)
       else Some (Vint32 Int.zero)) <> Vint32 Int.zero |- _ =>
      rename Hguard into Hi6_minus_one_zero_guard
  end.
  assert (Hi6_minus_one_zero : Int.eq (i6-ᵢ$ 1) ($ 0) = true).
  {
    destruct (Int.eq (i6-ᵢ$ 1) ($ 0));
      simpl in Hi6_minus_one_zero_guard; tryfalse; reflexivity.
  }
  eapply forward_rule2.
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_tcb_struct; discriminate Hbad_tcb_struct.
  eapply timetick_tcb_flag_type_match; eauto.
  left; reflexivity.
  eapply ne_0_minus_1_in_range;eauto.
  pauto.
  pauto.
  split_right; pauto.
  unfold OS_STAT_RDY; int auto.
  all: try solve [eapply timetick_sub_repr_range; eauto].
   
  intros.
  exists (Vptr (v'33, Int.zero))
         ( v'23 ++
                (v'32
                   :: v'9
                   :: x7
                   :: x6
                   :: Vint32 i6
                   :: Vint32 i5
                   :: Vint32 i4
                   :: Vint32 i3
                   :: Vint32 i2 :: Vint32 i1 :: Vint32 i0 :: nil)::nil)
         v'24
         v'32
         (v'26 ++( (v'32
              :: v'9
                 :: Vnull
                    :: x6
                       :: Vint32 (i6-ᵢ$ 1)
                          :: V$OS_STAT_RDY
                             :: Vint32 i4
                                :: Vint32 i3
                                   :: Vint32 i2
                                      :: Vint32 i1 :: Vint32 i0 :: nil)::nil)).
  sep semiauto.
  sep cancel evsllseg.
  unfold tcbdllseg at 2.
  sep cancel dllseg.

  apply tcbdllseg_compose_tail;auto.
 
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  rtmatch_solve.
  eapply ne_0_minus_1_in_range;eauto.
  pauto.
  pauto.
  split_right; pauto.
  all: try solve_byte_unsigned_leb.
  all: try solve [auto].
   
  assert (Hprefix_ex : exists prefix_rtbl prefix_tcbls,
      TCBList_P (Vptr v'4) v'23 prefix_rtbl prefix_tcbls).
  {
    eapply tcblist_p_recombine; eauto.
  }
  destruct Hprefix_ex as [prefix_rtbl [prefix_tcbls Hprefix_tcb]].
 
  assert (Hrltcbblk_again : RL_TCBblk_P
      (v'32 :: v'9 :: x7 :: x6 :: Vint32 i6 :: Vint32 i5 ::
       Vint32 i4 :: Vint32 i3 :: Vint32 i2 :: Vint32 i1 ::
       Vint32 i0 :: nil)).
  {
    eapply tcbnode_rl_prop; eauto.
  }
  eapply tcbls_rtbl_timetci_update_hold;eauto.
  1: {
    unfold RL_TCBblk_P in Hrltcbblk_again.
    simpl in Hrltcbblk_again.
    destruct Hrltcbblk_again as [prio Hrltcbblk_again].
    destruct Hrltcbblk_again as [tcbx Hrltcbblk_again].
    destruct Hrltcbblk_again as [tcby Hrltcbblk_again].
    destruct Hrltcbblk_again as [bitx Hrltcbblk_again].
    destruct Hrltcbblk_again as [bity Hrltcbblk_again].
    destruct Hrltcbblk_again as [stat Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hprio_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Htcbx_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Htcby_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hbitx_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hbity_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hstat_val Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hprio_range Hrltcbblk_again].
    destruct Hrltcbblk_again as [Htcbx_eq Hrltcbblk_again].
    destruct Hrltcbblk_again as [Htcby_eq Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hbitx_eq Hrltcbblk_again].
    destruct Hrltcbblk_again as [Hbity_eq Hstatus].
    inverts Hprio_val.
    inverts Htcbx_val.
    inverts Htcby_val.
    inverts Hbitx_val.
    inverts Hbity_val.
    inverts Hstat_val.
    unfold RL_TCBblk_P.
    simpl.
    exists prio.
    exists tcbx.
    exists tcby.
    exists bitx.
    exists bity.
    exists ($ OS_STAT_RDY).
    split_right; eauto.
    exists Vnull.
    simpl.
    auto.
  }
  1: {
    rewrite <- List.app_assoc.
    simpl.
    auto.
  }

  pure_intro'.
  assert (Int.eq i6 ($ 0) = false).
  clear -H15.
  destruct (Int.eq i6 ($ 0));simpl in H15;auto.
  unfold Int.notbool in H15.
  assert (Int.eq Int.one Int.zero = false).
  int auto.
  rewrite H in H15.
  tryfalse.
  assert (Int.eq (i6-ᵢ$ 1) ($ 0) = false).
  clear -H30.
  destruct (Int.eq (i6-ᵢ$ 1) ($ 0));simpl in H30;destruct H30;tryfalse;auto.
  clear H16 H15 H32 H28 H30 H31 H29.
  eapply forward_rule2.
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  intro Hbad_tcb_struct_nonzero; discriminate Hbad_tcb_struct_nonzero.
  eapply timetick_tcb_flag_type_match; eauto.
  eapply ne_0_minus_1_in_range;eauto.
  pauto.
  pauto.
  split_right; pauto.
   
  intros.
  exists (Vptr (v'33, Int.zero))
         ( v'23 ++
                (v'32
                   :: v'9
                   :: x7
                   :: x6
                   :: Vint32 i6
                   :: Vint32 i5
                   :: Vint32 i4
                   :: Vint32 i3
                   :: Vint32 i2 :: Vint32 i1 :: Vint32 i0 :: nil)::nil)
         v'24
         v'32
         (v'26 ++( (v'32
                      :: v'9
                      :: x7
                      :: x6
                      :: Vint32 (i6-ᵢ$ 1)
                      :: Vint32 i5
                      :: Vint32 i4
                      :: Vint32 i3
                      :: Vint32 i2
                      :: Vint32 i1 :: Vint32 i0 :: nil)::nil)).
  sep semiauto.
  sep cancel evsllseg.
  unfold tcbdllseg at 2.
  sep cancel dllseg.
  apply tcbdllseg_compose_tail;auto.
  
  simpl; split_right.
  pauto.
  pauto.
  pauto.
  pauto.
  rtmatch_solve.
  eapply ne_0_minus_1_in_range;eauto.
  pauto.
  pauto.
  split_right; pauto.
  all: try solve_byte_unsigned_leb.
  all: try solve [auto].
   


  eapply tcbls_rtbl_timetci_update_hold';eauto.
  rewrite <- List.app_assoc.
  simpl.
  auto.

  pure_intro'.
  assert (Int.eq i6 ($ 0) = true).
  clear -H15.
  destruct (Int.eq i6 ($ 0));simpl in H15;destruct H15;tryfalse;auto.
  eapply forward_rule2.
  hoare forward.
  (* intro;tryfalse. *)
  simpl; split_right; pauto.
  intro Hbad_tcb_struct_zero; discriminate Hbad_tcb_struct_zero.
  eapply timetick_tcb_flag_type_match; eauto.
  intros.
  exists (Vptr (v'33, Int.zero))
         ( v'23 ++
                (v'32
                   :: v'9
                   :: x7
                   :: x6
                   :: Vint32 i6
                   :: Vint32 i5
                   :: Vint32 i4
                   :: Vint32 i3
                   :: Vint32 i2 :: Vint32 i1 :: Vint32 i0 :: nil)::nil)
         v'24
         v'32
         (v'26 ++( (v'32
                      :: v'9
                      :: x7
                      :: x6
                      :: Vint32 i6
                      :: Vint32 i5
                      :: Vint32 i4
                      :: Vint32 i3
                      :: Vint32 i2
                      :: Vint32 i1 :: Vint32 i0 :: nil)::nil)).
  sep semiauto.
  sep cancel evsllseg.
  unfold tcbdllseg at 2.
  sep cancel dllseg.
  apply tcbdllseg_compose_tail;auto.
  simpl;split;pauto.
  eapply tcbls_rtbl_timetci_update_hold'';eauto.
  rewrite <- List.app_assoc.
  simpl.
  auto.
Qed.
