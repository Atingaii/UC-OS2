(**************************  uc/OS-II  ******************************)
(*************************** OS_Q.C *********************************)
(****Proofs for API Fucntion:  void* OSQAccept(OS_EVENT* pevent)*****)
(**************************** Code: *********************************)
(*** 
void  *OSQAccept (OS_EVENT *pevent)
{
    void      *msg;
    OS_Q      *pq;
    BOOLEAN   legal;
1   if (pevent == (OS_EVENT * )0) 
    {
2       return ((void * )0);
    }
3   OS_ENTER_CRITICAL();
4   legal = OS_EventSearch(pevent);
5   if (!legal)
    {
6       OS_EXIT_CRITICAL();
7       return ((void * )0);
    }
8   if ( pevent -> OSEventType  !=  OS_EVENT_TYPE_Q )
    {
9       OS_EXIT_CRITICAL(); 
10      return ((void * )0); 
    } 
11  pq = (OS_Q * )pevent->OSEventPtrs;
12  if (pq->OSQEntries > 0) 
    {
13      msg = *pq->OSQOut++;
14      pq->OSQEntries--;
15      if (pq->OSQOut == pq->OSQEnd)
        {
16          pq->OSQOut = pq->OSQStart;
        }
    } 
    else
    {
17      msg = (void * )0;
    }
18  OS_EXIT_CRITICAL();
19  return (msg);
}
***)
 
Require Import ucos_include. 
Require Import OSQAcceptPure.
Require Import msgq_absop_rules.

Open Scope code_scope.
Open Scope int_scope.
(* ------------------- OS Q Accept -------------------------*)


Ltac sep_lift_absdata H :=
  match type of H with
    | _ |= ?P =>
      match find_aop P with
        | none _ =>
          idtac 1 "no absop in the pre-condition"; fail 1
        | some ?a =>
          match find_absdata P absecblsid with
            | none _ =>
              idtac 2 "no HECBList in the pre-condition";
                fail 2
            | some ?b =>
              match find_absdata P abstcblsid with
                | none _ => 
                  idtac 3 "no HTCBList in the pre-condition"; fail 3
                | some ?c =>
                  match find_absdata P ostmid with
                    | none _ =>
                      idtac 4 "no HTime in the pre-condition"; fail 4
                    | some ?e =>
                      match find_absdata P curtid with
                        | none _ =>
                          idtac 5 "no HCurTCB in the pre-condition"; fail 5
                        | some ?f =>
                              sep lifts (a::b::c::e::f::nil)  in H
                          end
                      end
              end
          end
      end
  end.

Ltac find_aisris' Hp :=
  match Hp with
    | ?A ** ?B =>
      match find_aisris' A with
        | some ?a => constr:(some a)
        | none ?a =>
          match find_aisris' B with
            | some ?b => constr:(some (a + b)%nat)
            | none ?b => constr:(none (a + b)%nat)
          end
      end
    | A_isr_is_prop => constr:(some 1%nat)
    | _ => constr:(none 1%nat)
  end.

Ltac find_aisris Hp := let y := find_aisris' Hp in
                       eval compute in y.

Ltac isr_is_prop_elim':=
  match goal with
    | H:?s |= ?P |- ?s |= _ =>
      match find_aisr P with
        | none => idtac
        | some ?a =>
          match find_ais P with
            | none => idtac
            | some ?b =>
              match find_aisris P with
                | none => idtac
                | some ?c => sep lifts (a::b::c::nil)%nat in H;eapply elim_a_isr_is_prop in H;exact H
              end
          end
      end
  end.

Ltac isr_is_prop_elim:=eapply backward_rule1;[intros;isr_is_prop_elim' | ].

Ltac isr_is_prop_add':=
  match goal with
    | H:?s |= ?P |- ?s |= _ =>
      match find_aisr P with
        | none => idtac
        | some ?a =>
          match find_ais P with
            | none => idtac
            | some ?b =>
              sep lifts (a::b::nil)%nat in H;eapply add_a_isr_is_prop in H;exact H
          end
      end
  end.

Ltac isr_is_prop_add:=eapply backward_rule1;[intros;isr_is_prop_add' | ].

Ltac sep_lift_absdata' H :=
  match type of H with
    | _ |= ?P =>
      match find_aop P with
        | none _ =>
          idtac 1 "no absop in the pre-condition"; fail 1
        | some ?a =>
          match find_absdata P absecblsid with
            | none _ =>
              idtac 2 "no HECBList in the pre-condition";
                fail 2
            | some ?b =>
              match find_absdata P abstcblsid with
                | none _ => 
                  idtac 3 "no HTCBList in the pre-condition"; fail 3
                | some ?c =>
                  match find_absdata P ostmid with
                    | none _ =>
                      idtac 4 "no HTime in the pre-condition"; fail 4
                    | some ?e =>
                      match find_absdata P curtid with
                        | none _ =>
                          idtac 5 "no HCurTCB in the pre-condition"; fail 5
                        | some ?f =>
                          sep lifts (a::b::c::e::f::nil)  in H
                      end
                  end
              end
          end
      end
    end.

(*
Hint Resolve gooda_qcc retpost_osev.
*)
Open Scope code_scope.

Lemma OSQAccProof :
  forall tid vl p r, 
    Some p =
    BuildPreA' os_api OSQAccept
               (qacc, (Tptr Tvoid, Tptr os_ucos_h.OS_EVENT :: nil)) vl OSLInv tid init_lg ->
    Some r =
    BuildRetA' os_api OSQAccept
               (qacc, (Tptr Tvoid, Tptr os_ucos_h.OS_EVENT :: nil)) vl OSLInv tid init_lg ->
    exists t d1 d2 s,
      os_api OSQAccept = Some (t, d1, d2, s) /\
      {|OS_spec, GetHPrio, OSLInv, I, r, Afalse |} |-tid  {{p}} s {{Afalse}}.
Proof.
  init_spec; hoare unfold.
  (* parameter check ------------ L1 ~ L2 *)
  hoare unfold; hoare forward; pauto.
  pure_intro.
  assert(x=Vnull) by pauto.
  subst x.
  hoare_abscsq.
  apply noabs_oslinv.
  eapply qacc_absinfer_null; pauto.

  hoare forward;auto.
  hoare forward.

  (* encrit -----------------------L3 *)
  hoare forward prim.
  pure intro.
  assert (exists v, x= Vptr v) by pauto. 
  simpljoin1.
 
  (* function call OSQPtrSearch  -------------------- L4 *)
  unfold OSInv;hoare_unfold.
  hoare forward.
  sep cancel 1%nat 10%nat.
  sep cancel Aie.
  sep cancel Ais.
  sep cancel Acs.
  sep cancel Aisr.
  sep cancel AECBList.
  sep cancel AOSTCBList.
  sep cancel tcbdllflag.
  sep cancel AOSRdyTblGrp.
  sep cancel AOSTCBPrioTbl.
  exact H3.
  pauto.
  pauto.
  apply retpost_osev.
  intros.
  destruct H3.
  destruct H3.
  sep auto.
  sep auto.
  intros.
  sep auto.

  hoare unfold.
  eapply backward_rule1.
  intros;eapply disj_star_elim.
  eauto.
  apply disj_rule.

  (* return value check ------------ L5 ~ L7 *)
  pure intro.
  hoare forward.
  simpl; int auto.
  discriminate.
  instantiate (1:=Afalse).
  pure_intro.
  destruct H11; simpljoin1.
  pauto.
 
  2: {
    (* no queue*)
    pure intro.
    hoare forward. 
    simpl; int auto.
    discriminate.
    instantiate (1:=Afalse).
    inverts H7.
    hoare abscsq.
    apply noabs_oslinv.
    apply qacc_absinfer_no_q.
    pauto.
    intro.
    do 3 destruct H5;tryfalse.

  2: {
    eapply disj_rule.
    eapply backward_rule1.
    2:eapply pfalse_rule.
    intros.
    unfold1 sat in H5.
    simpljoin1; false.
    pure intro.

    destruct H5;
    assert (Int.eq ($ 0) ($ 0)=true) by pauto;
    rewrite H6 in H5;
    simpl in H5;tryfalse.
  }

    hoare forward prim.
    sep pauto.
    pauto.
    hoare forward.
  }

  (* check the event type------ L8 ~ L10 *)

  hoare forward.
  hoare unfold.
  hoare forward.
  pauto.
  pauto.
  pauto.

  1: { intro Hcontra; discriminate. }
  1: { pauto. }
  1: { destruct (Int.eq i0 ($ OS_EVENT_TYPE_Q)); simpl; discriminate. }
  1: { destruct (Int.eq i0 ($ OS_EVENT_TYPE_Q)); simpl; discriminate. }
  instantiate (1:=Afalse).
  hoare_split_pure_all.
  destruct H12.
  remember (Int.eq i0 ($ OS_EVENT_TYPE_Q)) as X.
  destruct X.
  unfold val_inj in H12.
  simpl in H12.
  unfold Int.notbool in H12.
  rewrite Int.eq_false in H12.
  tryfalse.
  clear.
  int auto.
  discriminate.

  eapply backward_rule1.
  intros.
  sep lift 8%nat in H20.
  eapply eventtype_neq_q in H20;eauto.
  hoare_split_pure_all.
  inverts H17.
  hoare abscsq.
  apply noabs_oslinv.
  eapply qacc_absinfer_no_q;auto.
  pauto.
  hoare forward prim.
  
  unfold AECBList.
  sep pauto.
  eapply evsllseg_compose.
  instantiate (2:= Vint32 i0 :: Vint32 i :: Vint32 i1 :: x2 :: x3 :: v'43 :: nil).
  unfold V_OSEventListPtr; simpl;  auto. 
  auto.
  auto.
  repeat (sep cancel evsllseg).
  (* AEventNode *)  

  unfold AEventNode.
  unfold AOSEvent.
  unfold AOSEventTbl.
  unfold node.
  sep pauto.
  sep cancel 1%nat 3%nat.
  sep cancel 1%nat 1%nat.
  eauto.
  eauto.
  unfolds;simpl;auto.
  auto.
  auto.
  pauto.
  auto.
  pauto.
  hoare forward.
  hoare forward.
  
  (*get the pointer of OSEVENT -------------- L11 *)
  pure intro. 
  hoare forward.
  simpl; pauto.
  
  (*check if has message ------------------ L12 *)
  apply val_inj_eq_q in H12.
  subst i0.
  unfold AEventData.
  destruct v'42.
  unfold AMsgData.
  unfold AOSQCtr.
  unfold AOSQBlk.
  hoare unfold.

  1: { intro Hcontra; discriminate. }
  1: { intro Hcontra; discriminate. }
  1: { intro Hcontra; discriminate. }
  1: { intro Hcontra; discriminate. }
  1: { pauto. }
  destruct v'42; tryfalse.
  unfold AEventData, AMsgData, AOSQCtr, AOSQBlk.
  hoare unfold.
  assert (exists i', x5 = Vptr (v'40, i')).
  eapply osq_same_blk_st_out';eauto.
  simpljoin1.
  
  hoare forward.
  1: { intro Hcontra; discriminate. }
  1: { pauto. }
  1: { destruct (Int.ltu ($ 0) i2); simpl; discriminate. }
  remember (Int.ltu ($ 0) i2) as Hbo.
  destruct Hbo; simpl; auto.
 
  (* get message ------------------------ L13*)
  pure intro.
  clear H28.

  Definition OSInv1 tid tcbl1 tcbcur tcbl2 p1 tcbls:=
    EX (eventl osql qblkl : list vallist) (msgql : list EventData)
       (ectrl : list os_inv.EventCtr) (ptbl : vallist) (p2 : val) 
       (rtbl : vallist) (rgrp : val) (ecbls : EcbMod.map) 
       (t : int32) (vhold : addrval) (ptfree : val) (lfree : list vallist),
    AOSEventFreeList eventl **
                     AOSQFreeList osql **
    AOSQFreeBlk qblkl **
    AECBList ectrl msgql ecbls tcbls **
    AOSMapTbl **
    AOSUnMapTbl **
    AOSTCBPrioTbl ptbl rtbl tcbls vhold **
    AOSIntNesting **
    AOSTCBList p1 p2 tcbl1 (tcbcur :: tcbl2) rtbl tid tcbls **
    AOSTCBFreeList ptfree lfree **
    AOSRdyTblGrp rtbl rgrp **
    AOSTime (Vint32 t) **
    HECBList ecbls **
    HTCBList tcbls **
    HTime t **
    HCurTCB tid ** AGVars ** [|RH_TCBList_ECBList_P ecbls tcbls tid|] ** A_isr_is_prop.
    
  instantiate (
      1:=
        <|| END (Some (nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2 ))||>  **
            LV pq @ os_ucos_h.OS_Q ∗ |-> Vptr (v'42, Int.zero)  **
            LV pevent @ os_ucos_h.OS_EVENT ∗ |-> Vptr  (v'27, Int.zero)  **
            LV message @ (Void) ∗
            |-> nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2  **
            LV legal @ Int8u |-> (V$1) **
            OSInv1 tid v'31 v'32 v'33 v'29 v'37 **
            atoy_inv' **
            Aisr empisr **
            Aie false **
            Ais nil **
            Acs (true :: nil) **
            A_dom_lenv
            ((pevent, os_ucos_h.OS_EVENT ∗)
               :: (message, (Void) ∗) :: (pq, os_ucos_h.OS_Q ∗) :: (legal, Int8u) :: nil) ** tcbdllflag v'29 (v'31 ++ v'32 :: v'33) ** p_local OSLInv tid init_lg **
            [|isptr (nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2)|]
    ).


(*

  
  instantiate (
      1:=
        <|| rendop (Some (nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2 ))||>  **
            LV pq @ OS_Q ∗ |-> Vptr (v'41, Int.zero) **
            LV pevent @ OS_EVENT ∗ |-> Vptr  (v'25, Int.zero) **
            LV message @ (Void) ∗
            |-> nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2 **
            LV legal @ Int8u |-> (V$1) **
            OSInv **
            atoy_inv' **
            Aisr empisr **
            Aie false **
            Ais nil **
            Acs (true :: nil) **
            A_dom_lenv
            ((pevent, OS_EVENT ∗)
               :: (message, (Void) ∗) :: (pq, OS_Q ∗) :: (legal, Int8u) :: nil) **
            [|isptr (nth_val' (Z.to_nat ((Int.unsigned x2 -  Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2)|]
    ).
*)
  hoare lift 4%nat pre.
  apply eq_sym in HeqHbo.
  pose proof
    (wellq_props x10 x9 x1 x4 v'40 x2 i3 i2 v'42 x x0 v2 v'47
       H33 HeqHbo H6 H20) as Hx.
  (*   HeqHbo : Int.ltu ($ 0) i0 = true
   * H6 : RLH_ECBData_P
   *        (DMsgQ (Vptr (v'42, Int.zero))
   *           (x10
   *            :: x9
   *               :: x1
   *                  :: x4
   *                     :: Vptr (v'40, x2)
   *                        :: Vint32 i2
   *                           :: Vint32 i0 :: Vptr (v'40, Int.zero) :: nil)
   *           (x :: x0 :: nil) v2) v'47
   *          H15 : WellformedOSQ
   *         (x10
   *          :: x9
   *             :: x1
   *                :: x4
   *                   :: Vptr (v'40, x2)
   *                      :: Vint32 i2
   *                         :: Vint32 i0 :: Vptr (v'40, Int.zero) :: nil) *)


  simpljoin1.
  fold Astruct'.
  fold Astruct.
  hoare lifts (11%nat::47%nat::nil)%list pre.
  lazymatch goal with
  | |- {| _, _, _, _, _, _ |} |- _ {{ ?P }} _ {{ _ }} =>
      lazymatch P with
      | _ ** _ ** ?R => remember R as Hmsgrest
      end
  end.
  eapply seq_rule
    with
      (p' := <|| v'49 ||> **
             LV message @ (Void) ∗
               |-> nth_val'
                     (Z.to_nat
                        ((Int.unsigned x2 -
                          Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) / 4))
                     v2 **
             Hmsgrest).
  {
    eapply assign_rule_lvar with (p' := Hmsgrest).
    - intro s; split; intro Hs; exact Hs.
    - intros s Hs.
      subst Hmsgrest.
      unfold id_addrval', id_addrval in H15.
      simpl in H15.
      inverts H15.
      eapply symbolic_lemmas.deref_ptr_of_array_member_rv
        with
          (i := Int.zero +ᵢ ($ 4 +ᵢ Int.zero))
          (i' := x2)
          (x := ((Int.unsigned x2 -
                  Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) / 4)%Z)
          (v := nth_val'
                  (Z.to_nat
                     ((Int.unsigned x2 -
                       Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) / 4)) v2)
          (n := ∘OS_MAX_Q_SIZE)
          (vl := v2)
          (t' := Tarray (Void ∗) ∘OS_MAX_Q_SIZE)
          (t := Void ∗).
      + eapply symbolic_lemmas.struct_member_rv_flag
          with (t := os_ucos_h.OS_Q).
        2: { unfold os_ucos_h.OS_Q; reflexivity. }
        2: { simpl; reflexivity. }
        2: { simpl; reflexivity. }
        2: { simpl; reflexivity. }
        2: { simpl; auto. }
        sep auto.
      + unfold Aarray.
        sep auto.
      + reflexivity.
      + simpl; lia.
      + simpl; lia.
      + simpl; lia.
      + exact H28.
      + reflexivity.
      + exact H41.
      + exact H42.
      + exact H43.
      + exact H44.
      + reflexivity.
    - apply assign_type_match_true; simpl; auto.
    - subst Hmsgrest; sep auto.
  }
  all: try solve [simpl; repeat split; pauto].

  subst Hmsgrest.
  hoare remember (1%nat::7%nat::13%nat::nil)%list pre.
  eapply seq_rule
    with
      (p' := <|| v'49 ||> **
             PV (v'42,
                 (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) @
               (Void ∗) ∗
               |-> Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)) **
             LV pq @ os_ucos_h.OS_Q ∗ |-> Vptr (v'42, Int.zero) **
             H45).
  {
    eapply assign_rule_general'
      with
        (l := (v'42,
                (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4))
        (v1 := Vptr (v'40, x2))
        (v2 := Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)))
        (p' := LV pq @ os_ucos_h.OS_Q ∗
               |-> Vptr (v'42, Int.zero) ** H45)
        (tp1 := (Void ∗) ∗) (tp2 := (Void ∗) ∗).
    - apply assign_type_match_true; simpl; auto.
    - intros st Hst.
      assert (st |= LV pq @ os_ucos_h.OS_Q ∗
                    |-> Vptr (v'42, Int.zero) ** Atrue) as Hpq.
      { sep pauto. }
      unfold os_ucos_h.OS_Q in Hpq.
      eapply symbolic_lemmas.field_asrt_impl
        with (tp := (Void ∗) ∗) (off := $ 16) in Hpq;
        [exact Hpq | simpl; reflexivity | simpl; reflexivity].
    - intros; split; intro Hs; exact Hs.
    - intros st Hst.
      eapply symbolic_lemmas.bop_rv
        with
          (v1 := Vptr (v'40, x2)) (t1 := (Void ∗) ∗)
          (v2 := Vint32 ($ 1)) (t2 := Tint32).
      + eapply symbolic_lemmas.struct_member_rv_flag
          with
            (t := os_ucos_h.OS_Q) (l := (v'42, Int.zero))
            (off := $ 16) (P := H45) (perm := true) (perm1 := true).
        * sep pauto.
        * unfold os_ucos_h.OS_Q; reflexivity.
        * simpl; reflexivity.
        * simpl; reflexivity.
        * simpl; reflexivity.
        * simpl; auto.
      + apply symbolic_lemmas.const_rv.
      + simpl; auto.
      + discriminate.
      + simpl; reflexivity.
    - subst H45; sep auto.
  }

  (* decrease the number of entrys ---------L14*)
  subst H45.
  hoare remember (1%nat::10%nat::3%nat::nil)%list pre.
  eapply seq_rule
    with
      (p' := <|| v'49 ||> **
             PV (v'42,
                 (((((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4)
                    +ᵢ $ 4) +ᵢ $ 2) @ Int16u
               |-> Vint32 (i2 -ᵢ $ 1) **
             LV pq @ os_ucos_h.OS_Q ∗ |-> Vptr (v'42, Int.zero) **
             H45).
  {
    eapply assign_rule_general'
      with
        (l := (v'42,
                (((((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4)
                   +ᵢ $ 4) +ᵢ $ 2))
        (v1 := Vint32 i2)
        (v2 := Vint32 (i2 -ᵢ $ 1))
        (p' := LV pq @ os_ucos_h.OS_Q ∗
               |-> Vptr (v'42, Int.zero) ** H45)
        (tp1 := Int16u) (tp2 := Tint32).
    - apply assign_type_match_true; simpl; auto.
    - intros st Hst.
      assert (st |= LV pq @ os_ucos_h.OS_Q ∗
                    |-> Vptr (v'42, Int.zero) ** Atrue) as Hpq.
      { sep pauto. }
      unfold os_ucos_h.OS_Q in Hpq.
      eapply symbolic_lemmas.field_asrt_impl
        with (tp := Int16u) (off := $ 22) in Hpq;
        [exact Hpq | simpl; reflexivity | simpl; reflexivity].
    - intros; split; intro Hs; exact Hs.
    - intros st Hst.
      eapply symbolic_lemmas.bop_rv
        with
          (v1 := Vint32 i2) (t1 := Int16u)
          (v2 := Vint32 ($ 1)) (t2 := Tint32).
      + eapply symbolic_lemmas.struct_member_rv_flag
          with
            (t := os_ucos_h.OS_Q) (l := (v'42, Int.zero))
            (off := $ 22) (P := H45) (perm := true) (perm1 := true).
        * sep pauto.
        * unfold os_ucos_h.OS_Q; reflexivity.
        * simpl; reflexivity.
        * simpl; reflexivity.
        * simpl; reflexivity.
        * simpl.
          destruct (Int.unsigned i2 <=? Int16.max_unsigned)%Z eqn:Hbound;
            simpl; auto.
          apply Z.leb_gt in Hbound.
          unfold Int16.max_unsigned in Hbound.
          simpl in Hbound.
          lia.
      + apply symbolic_lemmas.const_rv.
      + simpl; auto.
      + discriminate.
      + simpl; reflexivity.
    - subst H45; sep auto.
  }

  (* check if needs to reset OSQOut -------------- L15 ~ L16 *)
  subst H45.
  hoare forward.
  inverts H17.

  lets Hx: h_has_same_msg H6;eauto.
  simpl;auto.
  simpljoin1.

  assert ( EcbMod.get v'36 (v'27, Int.zero) = Some (absmsgq ((nth_val' (Z.to_nat ((Int.unsigned x2 - Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) / 4)) v2) :: x5)  x6 , x7)) as Hget.
  eapply EcbMod.join_joinsig_get;eauto.
  simpljoin1.
  hoare lifts (1%nat::32%nat::33%nat::45%nat::34%nat::nil)%list pre.
  eapply abscsq_rule'.
  apply noabs_oslinv.

(*  
  intro;mytac;tryfalse.
  intro;mytac;tryfalse.
 *)
  eapply qacc_absinfer_get_msg.
  2: { exact Hget. }
  can_change_aop_solver.
  change (can_change_aop
            (Aarray v'38 (Tarray (Void ∗) ∘OS_MAX_Q_SIZE) v2)).
  apply can_change_aop_ptrarray.
  change (can_change_aop
            (Aarray v'21 (Tarray Int8u ∘OS_EVENT_TBL_SIZE) v'41)).
  apply can_change_aop_ptrarray.

  hoare lifts (1%nat::7%nat::8%nat::13%nat::12%nat::nil)%list pre.
  hoare remember (1%nat::2%nat::3%nat::4%nat::5%nat::nil)%list pre.
  eapply forward_rule2.
  eapply ift_rule''
    with
      (v := val_inj
              (val_eq (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1))
      (q := <|| END Some
                    (nth_val'
                       (Z.to_nat
                          ((Int.unsigned x2 -
                            Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) /
                           4)) v2) ||> **
            PV (v'42,
                (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) @
              (Void ∗) ∗
              |-> x9 **
            LV pq @ os_ucos_h.OS_Q ∗ |-> Vptr (v'42, Int.zero) **
            PV (v'42, (Int.zero +ᵢ $ 4) +ᵢ $ 4) @ (Void ∗) ∗
              |-> x1 **
            PV (v'42, Int.zero +ᵢ $ 4) @ (Void ∗) ∗ |-> x9 **
            H17 **
            [|val_inj
                (val_eq
                   (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
              Vint32 Int.zero /\
              val_inj
                (val_eq
                   (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
              Vnull /\
              val_inj
                (val_eq
                   (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
              Vundef|]).
  - intros st Hst.
    eapply symbolic_lemmas.bop_rv
      with
        (v1 := Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)))
        (t1 := (Void ∗) ∗) (v2 := x1) (t2 := (Void ∗) ∗).
    + eapply symbolic_lemmas.struct_member_rv_flag
        with
          (t := os_ucos_h.OS_Q) (l := (v'42, Int.zero))
          (off := $ 16)
          (P := <|| END Some
                       (nth_val'
                          (Z.to_nat
                             ((Int.unsigned x2 -
                               Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) /
                              4)) v2) ||> **
                PV (v'42, (Int.zero +ᵢ $ 4) +ᵢ $ 4) @ (Void ∗) ∗
                  |-> x1 **
                PV (v'42, Int.zero +ᵢ $ 4) @ (Void ∗) ∗ |-> x9 ** H17)
          (perm := true) (perm1 := true).
      * assert (get_off_addr (v'42, Int.zero) ($ 16) =
                  (v'42,
                   (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4)) as Hoff.
        { unfold get_off_addr; simpl; f_equal; int auto. }
        rewrite Hoff; sep pauto.
      * unfold os_ucos_h.OS_Q; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * simpl; auto.
    + eapply symbolic_lemmas.struct_member_rv_flag
        with
          (t := os_ucos_h.OS_Q) (l := (v'42, Int.zero))
          (off := $ 8)
          (P := <|| END Some
                       (nth_val'
                          (Z.to_nat
                             ((Int.unsigned x2 -
                               Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) /
                              4)) v2) ||> **
                PV (v'42,
                    (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) @
                  (Void ∗) ∗
                  |-> Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)) **
                PV (v'42, Int.zero +ᵢ $ 4) @ (Void ∗) ∗ |-> x9 ** H17)
          (perm := true) (perm1 := true).
      * assert (get_off_addr (v'42, Int.zero) ($ 8) =
                  (v'42, (Int.zero +ᵢ $ 4) +ᵢ $ 4)) as Hoff.
        { unfold get_off_addr; simpl; f_equal; int auto. }
        rewrite Hoff; sep pauto.
      * unfold os_ucos_h.OS_Q; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * destruct H35 as [Hx1 | [p Hx1]]; subst x1; simpl; auto.
    + reflexivity.
    + apply vptr_inj_neq_Vundef.
      * unfold isptr; right; eexists; reflexivity.
      * exact H35.
    + simpl; reflexivity.
  - hoare normal pre.
    eapply assign_rule_general'
      with
        (l := (v'42,
                (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4))
        (v1 := Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)))
        (v2 := x9)
        (p' := LV pq @ os_ucos_h.OS_Q ∗
                 |-> Vptr (v'42, Int.zero) **
               PV (v'42, (Int.zero +ᵢ $ 4) +ᵢ $ 4) @ (Void ∗) ∗
                 |-> x1 **
               PV (v'42, Int.zero +ᵢ $ 4) @ (Void ∗) ∗ |-> x9 **
               H17 **
               [|val_inj
                   (val_eq
                      (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                    Vint32 Int.zero /\
                  val_inj
                    (val_eq
                       (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                    Vnull /\
                  val_inj
                    (val_eq
                       (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                    Vundef|])
        (tp1 := (Void ∗) ∗) (tp2 := (Void ∗) ∗).
    + apply assign_type_match_true; simpl; auto.
    + intros st Hst.
      assert (st |= LV pq @ os_ucos_h.OS_Q ∗
                    |-> Vptr (v'42, Int.zero) ** Atrue) as Hpq.
      { sep pauto. }
      unfold os_ucos_h.OS_Q in Hpq.
      eapply symbolic_lemmas.field_asrt_impl
        with (tp := (Void ∗) ∗) (off := $ 16) in Hpq;
        [exact Hpq | simpl; reflexivity | simpl; reflexivity].
    + intros; split; intro Hs; sep pauto.
    + intros st Hst.
      eapply symbolic_lemmas.struct_member_rv_flag
        with
          (t := os_ucos_h.OS_Q) (l := (v'42, Int.zero))
          (off := $ 4)
          (P := PV (v'42,
                    (((Int.zero +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) +ᵢ $ 4) @
                  (Void ∗) ∗
                  |-> Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)) **
                PV (v'42, (Int.zero +ᵢ $ 4) +ᵢ $ 4) @ (Void ∗) ∗
                  |-> x1 ** H17 **
                [|val_inj
                    (val_eq
                       (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                     Vint32 Int.zero /\
                   val_inj
                     (val_eq
                        (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                     Vnull /\
                   val_inj
                     (val_eq
                        (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))) x1) <>
                     Vundef|])
          (perm := true) (perm1 := true).
      * assert (get_off_addr (v'42, Int.zero) ($ 4) =
                    (v'42, Int.zero +ᵢ $ 4)) as Hoff.
        { unfold get_off_addr; reflexivity. }
        rewrite Hoff; sep pauto.
      * unfold os_ucos_h.OS_Q; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * simpl; reflexivity.
      * destruct H34 as [Hx9 | [p Hx9]]; subst x9; simpl; auto.
    + subst H17; sep auto.
  all: try can_change_aop_solver.
  - intros s Hsat.
  subst H17.
  destruct Hsat as [Hsat | Hsat].
  assert (Hqblkaddr :
            v'38 = (v'40, Int.zero +ᵢ ($ 4 +ᵢ Int.zero))).
  {
    unfold id_addrval', id_addrval in H15.
    simpl in H15.
    inversion H15; reflexivity.
  }
  subst v'38.
  sep remember
    (16::17::13::5::4::12::2::14::10::15::18::19::20::21::22::23::nil)%nat
    in Hsat.
  unfold AOSEventTbl in Hsat.
  assert (s|= AEventNode (Vptr (v'27, Int.zero)) 
             (V$OS_EVENT_TYPE_Q :: Vint32 i :: Vint32 i1 :: Vptr (v'42,Int.zero) :: x3 :: v'43 :: nil)
             v'41 
             (DMsgQ (Vptr (v'42,Int.zero)) 
                    (x10
                       :: x9
                       :: x1
                       :: x4
                       :: x9
                       :: Vint32 i3
                       :: Vint32 (i2-ᵢ$ 1) :: Vptr (v'40, Int.zero) :: nil)
                   (x :: x0 :: nil) v2) ** H17) as HAEvent.
  {
    unfold_msg.
    subst H17.
    sep semiauto; eauto.
    unfold AEventData.
    unfold AMsgData.
    unfold AOSQCtr.
    unfold AOSQBlk.
    unfold node.
    assert (x1 = Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))).
    {
      symmetry; apply val_inj_impl_eq; repeat split; assumption.
    }
    subst x1.
    pose proof
      (get_wellformedosq_end
         i2 x10 x9 v'40 x2 x4 (Vptr (v'40, x2))
         (Vint32 i3) (Vint32 i2) (Vptr (v'40, Int.zero))
         eq_refl HeqHbo H20) as Hwellformed.
    simpl in Hwellformed.
    pose proof Hsat as Hraw.
    sep auto.
    all: lazymatch goal with
         | |- WellformedOSQ _ => exact Hwellformed
         | |- V_qfreeblk _ = _ => unfold V_qfreeblk; simpl; auto
         | |- id_addrval' _ _ _ = _ => simpl; auto
         | |- _ = _ /\ struct_type_vallist_match _ _ =>
             simpl; repeat split; pauto
         | _ => idtac
         end.
    clear Hsat.
    rename Hraw into Hsat.
    unfold Astruct, Aarray.
    unfold os_ucos_h.OS_Q_FREEBLK, os_ucos_h.OS_Q, os_ucos_h.OS_EVENT.
    cbn [Astruct' Aarray' typelen].
    scancel.
  }

  clear Hsat.
  rename HAEvent into Hsat.
  subst H17.
  unfold OSInv1.
  sep semiauto.
  sep cancel AOSQFreeBlk.
  sep cancel AOSTCBList.
  sep cancel AOSQFreeList.

  sep cancel AOSEventFreeList.
  sep lifts (2::4::5::nil)%nat in Hsat.
  eapply evsllseg_compose in Hsat; eauto.
  unfold AECBList.

  sep auto.
  eapply msgqnode_p_hold_end in H6;eauto.
  
  lets Hnewjoin: ecb_get_set_join_join Hget H8 H19.
  simpljoin1.
  
  eapply msgqlist_p_compose;eauto.
  symmetry; apply val_inj_impl_eq; repeat split; assumption.
  sep split in Hsat.
  auto.
  simpl in H27;unfold isptr;destruct ( (nth_val'
             (Z.to_nat
                ((Int.unsigned x2 - Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) /
                 4)) v2));tryfalse;auto.
  right;exists a;auto.

  eapply rh_tcbls_mqls_p_getmsg_hold;eauto.
  auto.
  auto.
  
  (*****not end*****)
  
  sep split in Hsat.
  assert (x1 <> Vptr(v'40,(x2 +ᵢ Int.mul ($ 1) ($ 4)))).
  {
    intro Heqptr; subst x1.
    match goal with
    | Hfalse :
        context [val_eq
                   (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)))
                   (Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4)))] |- _ =>
        unfold val_eq in Hfalse;
        destruct (peq v'40 v'40) as [_ | Hneq]
        ; [rewrite Int.eq_true in Hfalse;
           simpl in Hfalse; destruct Hfalse; discriminate
          | contradiction]
    end.
  }

  eapply msgqnode_p_hold_no_end in H6;eauto.

  lets Hnewjoin: ecb_get_set_join_join Hget H8 H19.
  simpljoin1.
  assert
    (Hmqlsp :
       ECBList_P v'39 Vnull
         (v'23 ++
          ((V$ OS_EVENT_TYPE_Q
            :: Vint32 i :: Vint32 i1 :: Vptr (v'42, Int.zero)
            :: x3 :: v'43 :: nil, v'41) :: nil) ++ v'24)
         (v'25 ++
          (DMsgQ (Vptr (v'42, Int.zero))
             (x10 :: x9 :: x1 :: x4
              :: Vptr (v'40, x2 +ᵢ Int.mul ($ 1) ($ 4))
              :: Vint32 i3 :: Vint32 (i2 -ᵢ $ 1)
              :: Vptr (v'40, Int.zero) :: nil)
             (x :: x0 :: nil) v2 :: nil) ++ v'26)
         (EcbMod.set v'36 (v'27, Int.zero) (absmsgq x5 x6, x7)) v'37).
  {
    eapply msgqlist_p_compose; eauto.
  }

  unfold OSInv1.
  sep semiauto;eauto.
  sep cancel AOSQFreeBlk.
  sep cancel AOSQFreeList.
  sep cancel AOSTCBList.

  unfold AECBList.
  sep semiauto.

  eapply evsllseg_compose;eauto.
  intros.
  2: {
    sep cancel 17%nat 2%nat.
    sep cancel 17%nat 2%nat.
    sep cancel AOSEventFreeList.
    sep cancel AOSTCBFreeList.

    instantiate (1:= (DMsgQ (Vptr (v'42, Int.zero))
                            (x10 :: x9 :: x1 :: x4 ::Vptr (v'40, x2+ᵢ Int.mul ($ 1) ($ 4)) :: Vint32 i3 :: Vint32 (i2-ᵢ$ 1) :: Vptr (v'40,Int.zero) :: nil)
                            (x :: x0 :: nil)
                            v2)
                ).
    instantiate (1:=v'41).
    instantiate (1:= (V$OS_EVENT_TYPE_Q
                       :: Vint32 i :: Vint32 i1 :: Vptr (v'42,Int.zero) :: x3 :: v'43 :: nil) ).
    unfold AEventNode.
    unfold AEventData.
    unfold_msg.
    assert (Hqblkaddr :
              v'38 = (v'40, Int.zero +ᵢ ($ 4 +ᵢ Int.zero))).
    {
      unfold id_addrval', id_addrval in H15.
      simpl in H15.
      inversion H15; reflexivity.
    }
    subst v'38.
    pose proof
      (get_wellformedosq_end'
         i2 x10 x9 v'40 x2 x4 (Vint32 i3) (Vint32 i2)
         (Vptr (v'40, Int.zero)) x1 eq_refl H51 H20)
      as Hwellformed.
    simpl in Hwellformed.
    sep semiauto;eauto.
    unfold AMsgData.
    unfold AOSQCtr.
    unfold AOSQBlk.
    unfold node.
    pose proof Hsat as Hraw.
    sep auto.
    all: lazymatch goal with
         | |- WellformedOSQ _ => exact Hwellformed
         | |- V_qfreeblk _ = _ => unfold V_qfreeblk; simpl; auto
         | |- id_addrval' _ _ _ = _ => simpl; auto
         | |- _ = _ /\ struct_type_vallist_match _ _ =>
             simpl; repeat split; pauto
         | _ => idtac
         end.
    clear Hsat.
    rename Hraw into Hsat.
    unfold Astruct, Aarray.
    unfold os_ucos_h.OS_Q_FREEBLK, os_ucos_h.OS_Q, os_ucos_h.OS_EVENT.
    cbn [Astruct' Aarray' typelen].
    scancel.
    sep lift 8%nat in Hsat.
    match type of Hsat with
    | ?st |= ?A ** ?R =>
        change
          (st |= Aarray'
                   (v'40, Int.zero +ᵢ ($ 4 +ᵢ Int.zero))
                   ∘OS_MAX_Q_SIZE (Void ∗) v2 ** R)
          in Hsat
    end.
    sep cancel 1%nat 1%nat.
    sep cancel 3%nat 1%nat.
    sep cancel 2%nat 1%nat.
    sep cancel 3%nat 1%nat.
    sep cancel 1%nat 1%nat.
    sep cancel 2%nat 1%nat.
    do 6 (sep cancel 1%nat 1%nat).
    match type of Hsat with
    | ?st |= ?A =>
        change (st |= Aarray' v'21 ∘OS_EVENT_TBL_SIZE Int8u v'41)
          in Hsat
    end.
    exact Hsat.
  }
  unfold V_OSEventListPtr; simpl; auto.
  exact Hmqlsp.
  simpl in H26;unfold isptr;destruct ( (nth_val'
             (Z.to_nat
                ((Int.unsigned x2 - Int.unsigned (Int.zero+ᵢ($ 4+ᵢ Int.zero))) /
                 4)) v2));tryfalse;auto.
  right;exists a;auto.

  (* H26 : isptr (Vptr (v'42, Int.zero)) *)


  eapply rh_tcbls_mqls_p_getmsg_hold;eauto.

  (*--------------no msg L17 -----------------------*)
  - pure intro.
  match goal with
  | _ : context [Int.ltu ($ 0) ?entries] |- _ =>
      remember (Int.ltu ($ 0) entries) as X
  end.
  destruct H12;destruct X;tryfalse.

  - pure intro.
  match goal with
  | Hentries : context [Int.ltu ($ 0) ?entries] |- _ =>
      remember (Int.ltu ($ 0) entries) as X;
      destruct Hentries; destruct X; tryfalse;
      clear Hentries
  end.

  lets Hnomsg: msgqnode_p_nomsg H6;eauto.
  simpljoin1.
 
  lets Hgetnomsg: EcbMod.join_joinsig_get H19 H8.

  inverts H17.
  
  hoare abscsq.
  apply noabs_oslinv.
  eapply qacc_absinfer_no_msg;  pauto.
  can_change_aop_solver.
  hoare forward.
  - unfold OSInv1.
  apply disj_rule.
  hoare_split_pure_all.
  hoare forward prim.
  all: try solve
    [sep cancel 6%nat 1%nat; [exact H29 | pauto]].
  all: try solve [sep pauto | good_frm_sovler].
  hoare forward.
  unfold isptr in H29.
  destruct
    (nth_val'
       (Z.to_nat
          ((Int.unsigned x2 -
            Int.unsigned (Int.zero +ᵢ ($ 4 +ᵢ Int.zero))) / 4)) v2);
    simpl in H29 |- *;
    first
      [reflexivity
      | destruct H29 as [Hbad | Hbad];
        [discriminate | destruct Hbad as [? Hbad]; discriminate]].

  hoare forward prim.

  unfold AECBList.
  sep pauto.
  1: {
    eapply evsllseg_compose.
    instantiate
      (2 := V$ OS_EVENT_TYPE_Q
            :: Vint32 i :: Vint32 i1 :: Vptr (v'42, Int.zero)
               :: x3 :: v'43 :: nil).
    unfold V_OSEventListPtr; simpl; auto.
    auto.
    auto.
    repeat (sep cancel evsllseg).
    unfold AEventNode.
    unfold AOSEvent.
    unfold AOSEventTbl.
    unfold node.
    let null_frame :=
      constr:(LV message @ (Void) ∗ |-> Vnull **
              LV pq @ os_ucos_h.OS_Q ∗ |-> Vptr (v'42, Int.zero) **
              LV legal @ Int8u |-> (V$ 1) **
              LV pevent @ os_ucos_h.OS_EVENT ∗
                |-> Vptr (v'27, Int.zero) **
              A_dom_lenv
                ((pevent, os_ucos_h.OS_EVENT ∗)
                 :: (message, (Void) ∗)
                    :: (pq, os_ucos_h.OS_Q ∗)
                       :: (legal, Int8u) :: nil)) in
    let queue_data :=
      constr:(DMsgQ (Vptr (v'42, Int.zero))
                (x10 :: x9 :: x1 :: x4 :: Vptr (v'40, x2)
                 :: Vint32 i3 :: Vint32 i2
                    :: Vptr (v'40, Int.zero) :: nil)
                (x :: x0 :: nil) v2) in
    let rec instantiate_node P :=
      lazymatch P with
      | ?left ** ?right => instantiate_node left; instantiate_node right
      | Astruct (?b, Int.zero) os_ucos_h.OS_EVENT _ => unify b v'27
      | Aarray ?arr (Tarray Int8u ∘OS_EVENT_TBL_SIZE) ?tbl =>
          unify arr v'21; unify tbl v'41
      | AEventData _ ?data => unify data queue_data
      | ?frame => first [is_evar frame; unify frame null_frame | idtac]
      | _ => idtac
      end in
    lazymatch goal with
    | |- _ |= ?P => instantiate_node P
    end.
    unfold AEventData, AMsgData, AOSQCtr, AOSQBlk, node.
    sep pauto.
    all: try solve [eauto | unfolds; simpl; auto | pauto].
    clear -H28.
    sep cancel 2%nat 1%nat.
    sep cancel 2%nat 1%nat.
    repeat sep cancel 1%nat 1%nat.
    sep auto.
  }
  1: { exact H3. }
  1: { good_frm_sovler. }
  hoare forward.
  Unshelve.
  Ltac solve_impossible_event_data :=
    hoare lift 10%nat pre;
    apply backward_rule1 with Afalse;
    [ intros s0 Hsat;
      unfold AEventData in Hsat;
      sep normal in Hsat;
      sep destruct Hsat;
      sep split in Hsat;
      match goal with
      | Hqueue : context [Int.eq ?event_type ($ OS_EVENT_TYPE_Q)],
        Htype : V_OSEventType (Vint32 ?event_type :: _) = Some _ |- _ =>
          simpl in Htype;
          let Hevent_type := fresh "Hevent_type" in
          injection Htype as Hevent_type;
          rewrite Hevent_type in Hqueue;
          simpl in Hqueue;
          destruct Hqueue; discriminate
      end
    | apply pfalse_rule ].
  - solve_impossible_event_data.
  - solve_impossible_event_data.
  - solve_impossible_event_data.
Qed.


Close Scope code_scope.
