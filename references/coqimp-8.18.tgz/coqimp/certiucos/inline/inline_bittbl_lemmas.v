Require Import include_frm.
Require Import inline_definitions.
Require Import os_code_defs.
Require Import inline_tactics.
Require Import symbolic_lemmas.
Require Import sep_auto.
Require Import math_auto.
Require Import os_inv.
Require Import hoare_forward.
Require Import pure_lib.
Require Import abs_step.
Require Import pure.
Require Import ucos_bitsmap.

Local Open Scope list_scope.
Local Open Scope code_scope.
Local Open Scope int_scope.
Local Open Scope Z_scope.

Lemma and_not_zero:
  forall x,
    Int.unsigned x <= 128 ->
    Int.and (Int.not x) x = $ 0.
Proof.
  intros.
  mauto.
Qed.

Lemma event_wait_rl_tbl_grp':
  forall x10 x9 x8 x7 i10 i6 i5 i4 i3 i2 i1 i0 v'1 x,
    RL_TCBblk_P
      (x10 :: x9 :: x8 :: x7 :: Vint32 i10 :: Vint32 i6 ::
       Vint32 i5 :: Vint32 i4 :: Vint32 i3 :: Vint32 i2 ::
       Vint32 i1 :: nil) ->
    array_type_vallist_match Int8u v'1 ->
    Int.eq (x &ᵢ Int.not i2) ($ 0) = true ->
    RL_Tbl_Grp_P v'1 (Vint32 i0) ->
    RL_Tbl_Grp_P
      (update_nth_val (Z.to_nat (Int.unsigned i3)) v'1
                      (Vint32 (x &ᵢ Int.not i2)))
      (Vint32 (i0 &ᵢ Int.not i1)).
Proof.
  introv Hrl Harr Hint Hrll.
  assert (if Int.eq (x &ᵢ Int.not i2) ($ 0) then
            (x &ᵢ Int.not i2) = $ 0
          else (x &ᵢ Int.not i2) <> $ 0) by apply Int.eq_spec.
  rewrite Hint in H.
  rewrite H.
  unfolds in Hrl.
  funfold Hrl.
  funfold Hrll.
  unfolds.
  introv Hn Hnth Hvin.
  assert (n <> Z.to_nat (Int.unsigned (Int.shru x0 ($ 3))) \/
          n = Z.to_nat (Int.unsigned (Int.shru x0 ($ 3)))) by tauto.
  destruct H0.
  lets Hex : nth_upd_neq H0 Hnth.
  assert (Vint32 i0 = Vint32 i0) by auto.
  lets Hes : Hrll Hn Hex H1.
  destruct Hes.
  inverts Hvin.
  lets Hzx : math_prop_and H0; try lia; auto.
  splits.
  destruct H2.
  split.
  intros.
  apply H2.
  rewrite Int.and_assoc in H5.
  rewrite Hzx in H5.
  auto.
  intros.
  apply H4 in H5.
  rewrite Int.and_assoc.
  rewrite Hzx; auto.
  split.
  intros.
  destruct H3.
  rewrite Int.and_assoc in H4.
  rewrite Hzx in H4.
  apply H3; auto.
  intros.
  rewrite Int.and_assoc.
  rewrite Hzx.
  apply H3; auto.
  subst n.
  lets Hdx : nth_upd_eq Hnth.
  inverts Hdx.
  inverts Hvin.
  assert (0 <= Int.unsigned x0 < 64) by lia.
  lets Hdd : math_prop_eq0 H0.
  split.
  split; auto.
  intros.
  rewrite Int.and_assoc.
  rewrite Hdd.
  rewrite Int.and_zero.
  auto.
  rewrite Int.and_assoc.
  rewrite Hdd.
  rewrite Int.and_zero.
  split.
  intros.
  apply math_lshift_neq_zero in H0.
  tryfalse.
  intros.
  clear -H1.
  false.
Qed.

Lemma event_wait_rl_tbl_grp'':
  forall x10 x9 x8 x7 i10 i6 i5 i4 i3 i2 i1 i0 v'1 x,
    RL_TCBblk_P
      (x10 :: x9 :: x8 :: x7 :: Vint32 i10 :: Vint32 i6 ::
       Vint32 i5 :: Vint32 i4 :: Vint32 i3 :: Vint32 i2 ::
       Vint32 i1 :: nil) ->
    array_type_vallist_match Int8u v'1 ->
    nth_val' (Z.to_nat (Int.unsigned i3)) v'1 = Vint32 x ->
    Int.eq (x &ᵢ Int.not i2) ($ 0) = false ->
    RL_Tbl_Grp_P v'1 (Vint32 i0) ->
    RL_Tbl_Grp_P
      (update_nth_val (Z.to_nat (Int.unsigned i3)) v'1
                      (Vint32 (x &ᵢ Int.not i2)))
      (Vint32 i0).
Proof.
  introv Hrl Harr Htt Hnth Hrt.
  funfold Hrl.
  funfold Hrt.
  assert (0 <= Int.unsigned x0 < 64) as Hran by lia.
  clear H5 H13.
  unfolds.
  introv Hn Hnv Hvi.
  inverts Hvi.
  assert (n <> Z.to_nat (Int.unsigned (Int.shru x0 ($ 3))) \/
          n = Z.to_nat (Int.unsigned (Int.shru x0 ($ 3)))) by tauto.
  destruct H.
  lets Hex : nth_upd_neq H Hnv.
  assert (Vint32 v' = Vint32 v') by auto.
  lets Hexz : Hrt Hn Hex H0.
  destruct Hexz as (He1 & He2).
  auto.
  subst n.
  lets Hins : nth_upd_eq Hnv.
  apply nth_val'_imp_nth_val_int in Htt.
  assert (Vint32 v' = Vint32 v') by auto.
  lets Hdx : Hrt Hn Htt H.
  inverts Hins.
  split.
  split.
  destruct Hdx.
  intros.
  apply H0 in H2.
  subst.
  rewrite Int.and_commut.
  rewrite Int.and_zero.
  auto.
  intros.
  rewrite H0 in Hnth.
  rewrite Int.eq_true in Hnth.
  tryfalse.
  split.
  intros.
  destruct Hdx.
  apply H2 in H0.
  apply int_eq_false_ltu; eauto.
  intros.
  destruct Hdx.
  apply H2.
  apply int_eq_false_ltu; eauto.
  apply Int.eq_false.
  assert (x <> $ 0 \/ x = $ 0) by tauto.
  destruct H3; auto.
  subst x.
  rewrite Int.and_commut in Hnth.
  rewrite Int.and_zero in Hnth.
  unfold Int.zero in Hnth.
  rewrite Int.eq_true in Hnth.
  tryfalse.
Qed.
